import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout, Button, Badge, Dropdown, Space, Avatar, message } from 'antd';
import {
  ShoppingCartOutlined,
  UserOutlined,
  LogoutOutlined,
  HomeOutlined,
  ShoppingOutlined //导入商品图标
} from '@ant-design/icons';
import { getCartList } from '../api/front/cartApi';

const { Header: AntHeader } = Layout;

function Header() {
  const navigate = useNavigate();
  const location = useLocation();
  const [cartCount, setCartCount] = useState(0);
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));
  const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');

  // 获取购物车数量
  const fetchCartCount = async () => {
    if (!isLoggedIn) {
      // 未登录时从localStorage获取购物车
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(localCart.length);
      return;
    }

    try {
      const res = await getCartList();
      if (res.code === 200) {
        const count = res.data?.reduce((sum, item) => sum + (item.quantity || 0), 0) || 0;
        setCartCount(count);
      }
    } catch (err) {
    }
  };

  useEffect(() => {
    setIsLoggedIn(!!localStorage.getItem('token'));
    fetchCartCount();

    // 监听购物车更新事件
    const handleCartUpdate = () => {
      fetchCartCount();
    };
    window.addEventListener('cartUpdated', handleCartUpdate);

    return () => {
      window.removeEventListener('cartUpdated', handleCartUpdate);
    };
  }, [location.pathname, isLoggedIn]);

  // 用户菜单
  const userMenuItems = isLoggedIn
    ? [
        {
          key: 'profile',
          label: '个人中心',
          icon: <UserOutlined />,
          onClick: () => navigate('/profile')
        },
        {
          key: 'orders',
          label: '我的订单',
          onClick: () => navigate('/orders')
        },
        {
          type: 'divider'
        },
        {
          key: 'logout',
          label: '退出登录',
          icon: <LogoutOutlined />,
          danger: true,
          onClick: () => {
            localStorage.removeItem('token');
            localStorage.removeItem('userInfo');
            setIsLoggedIn(false);
            message.success('已退出登录');
            navigate('/');
          }
        }
      ]
    : [
        {
          key: 'login',
          label: '登录',
          onClick: () => navigate('/login')
        },
        {
          key: 'register',
          label: '注册',
          onClick: () => navigate('/register')
        }
      ];

  return (
    <AntHeader
      style={{
        background: '#fff',
        padding: '0 50px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        position: 'sticky',
        top: 0,
        zIndex: 1000
      }}
    >
      {/* Logo和首页 */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          cursor: 'pointer'
        }}
        onClick={() => navigate('/')}
      >
        <HomeOutlined style={{ fontSize: '24px', color: '#1890ff', marginRight: '8px' }} />
        <span style={{ fontSize: '20px', fontWeight: 'bold', color: '#1890ff' }}>
          kingso跨境电商
        </span>
      </div>

      {/* 右侧功能区 */}
      <Space size="large">
        {/* 商品按钮（购物车左侧） */}
        <Button
          type="text"
          icon={<ShoppingOutlined style={{ fontSize: '20px' }} />}
          onClick={() => navigate('/products')} // 跳转至商品列表页
          style={{ fontSize: '16px' }}
        >
          商品
        </Button>

        {/* 购物车 */}
        <Badge count={cartCount} showZero>
          <Button
            type="text"
            icon={<ShoppingCartOutlined style={{ fontSize: '20px' }} />}
            onClick={() => navigate('/cart')}
            style={{ fontSize: '16px' }}
          >
            购物车
          </Button>
        </Badge>

        {/* 用户菜单 */}
        {isLoggedIn ? (
          <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
            <Space style={{ cursor: 'pointer' }}>
              <Avatar icon={<UserOutlined />} src={userInfo.avatar} />
              <span>{userInfo.nickname || userInfo.username || '用户'}</span>
            </Space>
          </Dropdown>
        ) : (
          <Space>
            <Button type="text" onClick={() => navigate('/login')}>
              登录
            </Button>
            <Button type="primary" onClick={() => navigate('/register')}>
              注册
            </Button>
          </Space>
        )}
      </Space>
    </AntHeader>
  );
}

export default Header;