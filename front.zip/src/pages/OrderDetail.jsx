import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Descriptions, Tag, Button, message, Spin, Space, Table } from 'antd';
import { ArrowLeftOutlined } from '@ant-design/icons';
import { getOrderWithItem, cancelOrder, confirmOrder } from '../api/front/orderApi';

function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);

  // 订单状态映射
  const statusMap = {
    0: { text: '待发货', color: 'orange' },
    1: { text: '已发货', color: 'blue' },
    2: { text: '已收货', color: 'green' },
    3: { text: '已完成', color: 'green' },
    9: { text: '已取消', color: 'default' }
  };

  // 格式化日期时间
  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return '-';
    try {
      const date = new Date(dateTimeStr);
      return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (err) {
      return dateTimeStr;
    }
  };

  // 获取订单详情及明细
  const fetchOrderDetail = async () => {
    setLoading(true);
    try {
      const res = await getOrderWithItem(id);
      if (res.code === 200) {
        // 返回的数据结构：{ order: Order, orderItemList: OrderItem[] }
        setOrder(res.data?.order || res.data);
        setOrderItems(res.data?.orderItemList || []);
      } else {
        message.error(res.msg || '获取订单详情失败');
        navigate('/orders');
      }
    } catch (err) {
      message.error('获取订单详情失败');
      navigate('/orders');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchOrderDetail();
    }
  }, [id]);

  // 取消订单
  const handleCancel = async () => {
    try {
      const res = await cancelOrder(id);
      if (res.code === 200) {
        message.success('订单已取消');
        fetchOrderDetail();
      }
    } catch (err) {
      message.error('取消订单失败');
    }
  };

  // 确认收货
  const handleConfirm = async () => {
    try {
      const res = await confirmOrder(id);
      if (res.code === 200) {
        message.success('订单已确认收货');
        fetchOrderDetail();
      }
    } catch (err) {
      message.error('确认收货失败');
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '100px' }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!order) {
    return null;
  }

  const statusInfo = statusMap[order.status] || { text: '未知', color: 'default' };

  return (
    <div style={{ padding: '20px 50px', background: '#f5f5f5', minHeight: 'calc(100vh - 80px)' }}>
      <Card>
        <div style={{ marginBottom: '20px' }}>
          <Button
            icon={<ArrowLeftOutlined />}
            onClick={() => navigate('/orders')}
          >
            返回订单列表
          </Button>
        </div>

        <Descriptions title="订单信息" bordered column={2}>
          <Descriptions.Item label="订单号">{order.orderNo}</Descriptions.Item>
          <Descriptions.Item label="订单状态">
            <Tag color={statusInfo.color}>{statusInfo.text}</Tag>
          </Descriptions.Item>
          <Descriptions.Item label="订单金额">¥{Number(order.totalAmount || 0).toFixed(2)}</Descriptions.Item>
          <Descriptions.Item label="创建时间">{formatDateTime(order.createTime)}</Descriptions.Item>
          <Descriptions.Item label="收货人">{order.receiverName || '-'}</Descriptions.Item>
          <Descriptions.Item label="联系电话">{order.receiverPhone || '-'}</Descriptions.Item>
          <Descriptions.Item label="收货地址" span={2}>{order.receiverAddress || '-'}</Descriptions.Item>
          {order.remark && (
            <Descriptions.Item label="订单备注" span={2}>{order.remark}</Descriptions.Item>
          )}
        </Descriptions>

        {/* 订单明细 */}
        <Card title="订单明细" style={{ marginTop: '20px' }}>
          <Table
            columns={[
              {
                title: '商品名称',
                dataIndex: 'goodsName',
                key: 'goodsName',
                width: 300
              },
              {
                title: '单价',
                dataIndex: 'goodsPrice',
                key: 'goodsPrice',
                width: 120,
                align: 'right',
                render: (price) => `¥${Number(price || 0).toFixed(2)}`
              },
              {
                title: '数量',
                dataIndex: 'num',
                key: 'num',
                width: 100,
                align: 'center'
              },
              {
                title: '小计',
                dataIndex: 'totalPrice',
                key: 'totalPrice',
                width: 120,
                align: 'right',
                render: (price) => <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>¥{Number(price || 0).toFixed(2)}</span>
              }
            ]}
            dataSource={orderItems}
            rowKey="id"
            pagination={false}
            summary={(pageData) => {
              const totalQuantity = pageData.reduce((sum, item) => sum + (item.num || 0), 0);
              const totalAmount = pageData.reduce((sum, item) => sum + Number(item.totalPrice || 0), 0);
              return (
                <Table.Summary fixed>
                  <Table.Summary.Row>
                    <Table.Summary.Cell index={0} colSpan={2}>
                      <span style={{ fontWeight: 'bold' }}>合计</span>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={2} align="center">
                      <span style={{ fontWeight: 'bold' }}>{totalQuantity}</span>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={3} align="right">
                      <span style={{ color: '#ff4d4f', fontWeight: 'bold', fontSize: '16px' }}>
                        ¥{totalAmount.toFixed(2)}
                      </span>
                    </Table.Summary.Cell>
                  </Table.Summary.Row>
                </Table.Summary>
              );
            }}
          />
        </Card>

        {/* 操作按钮 */}
        <div style={{ marginTop: '20px', textAlign: 'right' }}>
          <Space>
            <Button onClick={() => navigate('/orders')}>
              返回订单列表
            </Button>
            {order.status === 1 && (
              <Button type="primary" onClick={handleConfirm}>
                确认收货
              </Button>
            )}
          </Space>
        </div>
      </Card>
    </div>
  );
}

export default OrderDetail;

