import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom';
import { Card, Form, Input, Button, Table, message, Space, Typography, Divider, Select, Badge, Row, Col, Modal, Radio } from 'antd';
import { getCartList, deleteCartItem } from '../api/front/cartApi';
import { createOrder } from '../api/front/orderApi';
import { commonMenuConfig } from '../components/Header';
import { isLoggedIn, getUserId } from '../utils/auth';

const { Title } = Typography;
const { TextArea } = Input;
const { Option } = Select;

function Order() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [form] = Form.useForm();
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [cartCount, setCartCount] = useState(0);

  // 从URL参数获取商品信息
  const goodsId = searchParams.get('goodsId');
  const quantity = parseInt(searchParams.get('quantity') || '1');
  const cartIdsString = searchParams.get('cartIds') || '';
  const cartIds = useMemo(() => {
    return cartIdsString ? cartIdsString.split(',').filter(Boolean) : [];
  }, [cartIdsString]);

  // 获取购物车数量
  const fetchCartCount = async () => {
    if (!isLoggedIn()) {
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(localCart.length);
      return;
    }
    try {
      const userId = getUserId();
      if (!userId) {
        return;
      }
      const res = await getCartList(userId);
      if (res.code === 200) {
        const count = res.data?.reduce((sum, item) => sum + (item.num || 0), 0) || 0;
        setCartCount(count);
      }
    } catch (err) {
      // 购物车数量获取失败，静默处理，不影响订单页面显示
      // 如果是 403 错误，可能是接口路径或权限问题
      if (err.response?.status === 403) {
        // 静默处理，不显示错误提示
      }
    }
  };

  // 获取订单商品（只在 URL 参数变化时执行）
  useEffect(() => {
    const fetchOrderItems = async () => {
      if (!isLoggedIn()) {
        message.warning('请先登录');
        navigate('/login');
        return;
      }

      setLoading(true);
      try {
        // 获取用户ID
        const userId = getUserId();

        // 订单明细信息全部来自购物车
        // 无论是立即购买还是购物车结算，都从购物车获取商品信息
        if (goodsId) {
          // 立即购买：单个商品
          // 注意：立即购买时，商品应该已经在购物车中（从商品详情页加入购物车后跳转）
          // 从购物车中查找对应的商品
          try {
            const res = await getCartList(userId);
            if (res.code === 200) {
              // 从购物车中查找指定商品ID的商品
              const cartItem = res.data.find(item => {
                const itemGoodsId = item.goodsId || item.goods?.id || item.goods?.goodsId;
                return String(itemGoodsId) === String(goodsId);
              });
              
              if (cartItem) {
                // 找到购物车中的商品，使用购物车数据
                const warehouseId = cartItem.warehouseId || cartItem.warehouse_id || cartItem.warehouse?.id || '';
                setOrderItems([{
                  ...cartItem,
                  quantity: quantity || cartItem.num || cartItem.quantity || 1,
                  num: quantity || cartItem.num || cartItem.quantity || 1,
                  goodsPrice: cartItem.goodsPrice || cartItem.goods?.goodsPrice || 0,
                  goodsName: cartItem.goodsName || cartItem.goods?.goodsName || '商品',
                  goodsImg: cartItem.goodsImg || cartItem.goods?.goodsImg || '',
                  goodsId: cartItem.goodsId || cartItem.goods?.id || cartItem.goods?.goodsId || 0,
                  warehouseId: warehouseId
                }]);
              } else {
                // 购物车中没有该商品，提示用户先加入购物车
                message.warning('商品不在购物车中，请先加入购物车');
                navigate(`/products/${goodsId}`);
              }
            } else {
              message.error(res.msg || '获取购物车数据失败');
            }
          } catch (err) {
            const errorMsg = err.response?.data?.msg || err.message || '获取购物车数据失败';
            message.error(errorMsg);
            // 跳转回首页
            setTimeout(() => {
              navigate('/');
            }, 2000);
          }
        } else if (cartIds.length > 0) {
          // 购物车结算，多个商品
          // 注意：完全使用购物车数据，不调用商品详情接口（避免403权限问题）
          try {
            const res = await getCartList(userId);
            if (res.code === 200) {
              const items = res.data.filter(item => cartIds.includes(String(item.id)));
              
              if (items.length === 0) {
                message.warning('购物车中没有选中的商品，请返回购物车重新选择');
                navigate('/cart');
                return;
              }
              
              // 直接使用购物车数据，不调用商品详情接口
              const itemsWithGoodsInfo = items.map((item) => {
                // 提取仓库ID
                const warehouseId = item.warehouseId || item.warehouse_id || item.warehouse?.id || '';
                
                return {
                  ...item,
                  goodsPrice: item.goodsPrice || item.goods?.goodsPrice || 0,
                  goodsName: item.goodsName || item.goods?.goodsName || '商品',
                  goodsImg: item.goodsImg || item.goods?.goodsImg || '',
                  goodsId: item.goodsId || item.goods?.id || item.goods?.goodsId || 0,
                  warehouseId: warehouseId,
                  quantity: item.num || item.quantity || 1,
                  num: item.num || item.quantity || 1
                };
              });
                
              setOrderItems(itemsWithGoodsInfo);
            } else {
              message.error(res.msg || '获取购物车数据失败');
            }
          } catch (err) {
            const errorMsg = err.response?.data?.msg || err.message || '获取购物车数据失败';
            if (err.response?.status === 403) {
              message.error('访问被拒绝：无法获取购物车数据，请检查权限或联系管理员');
            } else {
              message.error(errorMsg);
            }
            // 跳转回购物车页面
            setTimeout(() => {
              navigate('/cart');
            }, 2000);
          }
        }
      } catch (err) {
        message.error('获取订单商品失败');
      } finally {
        setLoading(false);
      }
    };

    fetchOrderItems();
  }, [goodsId, quantity, cartIdsString, navigate]);

  // 获取购物车数量（只执行一次）
  useEffect(() => {
    fetchCartCount();
    
    // 监听购物车更新事件
    const handleCartUpdate = () => fetchCartCount();
    window.addEventListener('cartUpdated', handleCartUpdate);
    
    return () => {
      window.removeEventListener('cartUpdated', handleCartUpdate);
    };
  }, []); // 空依赖数组，只执行一次

  // 响应式处理
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 计算总价
  const calculateTotal = () => {
    return orderItems.reduce((sum, item) => {
      const price = Number(item.goodsPrice || 0);
      const qty = Number(item.quantity || item.num || 1);
      return sum + price * qty;
    }, 0);
  };


  // 提交订单
  const handleSubmit = async (values) => {
    if (orderItems.length === 0) {
      message.warning('订单商品不能为空');
      return;
    }

    if (!values.receiverName) {
      message.warning('请输入联系人姓名');
      return;
    }

    if (!values.receiverPhone) {
      message.warning('请输入联系电话');
      return;
    }

    if (!values.receiverAddress) {
      message.warning('请输入收货地址');
      return;
    }

    // 获取用户ID
    const userId = getUserId();
    if (!userId) {
      message.error('用户信息获取失败，请重新登录');
      navigate('/login');
      return;
    }

    setSubmitting(true);
    try {
      // 构建订单明细列表
      const orderItemList = orderItems.map(item => {
        // 确保商品名称正确提取（兼容多种字段名）
        const goodsName = item.goodsName || item.goods_name || item.name || item.goods?.goodsName || '';
        
        // 提取仓库ID
        const warehouseId = item.warehouseId || item.warehouse_id || item.warehouse?.id || '';
        
        return {
          goodsId: item.goodsId || item.id || 0,
          goodsName: goodsName,
          goodsPrice: Number(item.goodsPrice || 0),
          num: Number(item.num || item.quantity || 1),
          warehouseId: warehouseId
        };
      });

      // 计算订单总金额
      const totalAmount = calculateTotal();

      // 按照 OrderAddDTO 格式构建订单数据
      const orderData = {
        userId: userId,
        totalAmount: totalAmount,
        receiverName: values.receiverName || '',
        receiverPhone: values.receiverPhone || '',
        receiverAddress: values.receiverAddress || '',
        payWay: values.payWay || '', // 支付方式
        status: 0, // 默认待发货
        remark: values.remark || '',
        orderItemList: orderItemList
      };

      // 直接提交订单
      try {
        const res = await createOrder(orderData);
        if (res.code === 200) {
          message.success('订单创建成功');
          
          // 清空购物车中已下单的商品
          try {
            // 收集所有需要删除的购物车项ID
            const cartItemIdsToDelete = orderItems
              .map(item => item.id)
              .filter(id => id != null && id !== undefined);
            
            // 批量删除购物车项
            if (cartItemIdsToDelete.length > 0) {
              const deletePromises = cartItemIdsToDelete.map(cartItemId => 
                deleteCartItem({ id: cartItemId, userId: userId })
              );
              
              // 等待所有删除操作完成（不阻塞页面跳转）
              Promise.all(deletePromises).then(() => {
                // 触发购物车更新事件，更新购物车数量
                window.dispatchEvent(new Event('cartUpdated'));
              }).catch(() => {
                // 删除失败不影响订单创建成功，静默处理
              });
            }
          } catch (err) {
            // 清空购物车失败不影响订单创建成功，静默处理
          }
          
          // 跳转到订单详情页，使用返回的订单ID
          const orderId = res.data?.id || res.data?.orderId;
          if (orderId) {
            navigate(`/orders/${orderId}`);
          } else {
            navigate('/orders');
          }
        } else {
          message.error(res.msg || '订单创建失败');
        }
      } catch (err) {
        const errorMsg = err.response?.data?.msg || err.message || '订单创建失败';
        message.error(errorMsg);
      } finally {
        setSubmitting(false);
      }
    } catch (err) {
      message.error('订单数据构建失败，请重试');
      setSubmitting(false);
    }
  };

  const columns = [
    {
      title: '商品ID',
      key: 'goodsId',
      width: 100,
      align: 'center',
      render: (_, record) => record.goodsId || record.id || '-'
    },
    {
      title: '商品图片',
      key: 'goodsImg',
      width: 100,
      align: 'center',
      render: (_, record) => (
        <img
          src={record.goodsImg || record.img || ''}
          alt={record.goodsName || '商品图片'}
          style={{ 
            width: '60px', 
            height: '60px', 
            objectFit: 'cover', 
            borderRadius: '4px',
            border: '1px solid #e8e8e8'
          }}
          onError={(e) => {
            //
          }}
        />
      )
    },
    {
      title: '商品名称',
      key: 'goodsName',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (_, record) => (
        <span title={record.goodsName || record.name || '-'}>
          {record.goodsName || record.name || '-'}
        </span>
      )
    },
    {
      title: '单价',
      dataIndex: 'goodsPrice',
      key: 'goodsPrice',
      width: 120,
      align: 'right',
      render: (price) => `¥${Number(price || 0).toFixed(2)}`
    },
    {
      title: '数量',
      key: 'quantity',
      width: 100,
      align: 'center',
      render: (_, record) => record.quantity || record.num || 1
    },
    {
      title: '小计',
      key: 'subtotal',
      width: 120,
      align: 'right',
      render: (_, record) => {
        const price = Number(record.goodsPrice || 0);
        const qty = Number(record.quantity || record.num || 1);
        return <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>¥{(price * qty).toFixed(2)}</span>;
      }
    }
  ];

  return (
    <div style={{ 
      padding: isMobile ? '10px' : '20px 50px', 
      background: '#f5f5f5', 
      minHeight: 'calc(100vh - 80px)',
      paddingBottom: isMobile ? '80px' : '20px'
    }}>
      <Card>
        <Title level={isMobile ? 4 : 3}>确认订单</Title>
        <Divider />

        <Form 
          form={form} 
          layout="vertical" 
          onFinish={handleSubmit}
          initialValues={{
            payWay: '货到付款'
          }}
        >
          {/* 联系人信息和收货地址 */}
          <Card title="收货信息" style={{ marginBottom: '20px' }}>
            <Row gutter={16}>
              <Col xs={24} sm={12}>
                <Form.Item
                  name="receiverName"
                  label="联系人"
                  rules={[{ required: true, message: '请输入联系人姓名' }]}
                >
                  <Input placeholder="请输入联系人姓名" />
                </Form.Item>
              </Col>
              <Col xs={24} sm={12}>
                <Form.Item
                  name="receiverPhone"
                  label="联系电话"
                  rules={[
                    { required: true, message: '请输入联系电话' },
                    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号码' }
                  ]}
                >
                  <Input placeholder="请输入手机号码" maxLength={11} />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item
              name="receiverAddress"
              label="收货地址"
              rules={[{ required: true, message: '请输入收货地址' }]}
            >
              <TextArea 
                placeholder="请输入详细收货地址" 
                rows={3}
                showCount
                maxLength={100}
              />
            </Form.Item>
          </Card>

          {/* 订单商品 */}
          <Card title="订单商品" style={{ marginBottom: '20px' }}>
            <Table
              columns={columns}
              dataSource={orderItems}
              rowKey="id"
              pagination={false}
              loading={loading}
            />
          </Card>

          {/* 支付方式 */}
          <Card title="支付方式" style={{ marginBottom: '20px' }}>
            <Form.Item
              name="payWay"
              label="请选择支付方式"
              rules={[{ required: true, message: '请选择支付方式' }]}
            >
              <Radio.Group>
                <Radio value="支付宝">支付宝</Radio>
                <Radio value="微信">微信</Radio>
                <Radio value="银行卡">银行卡</Radio>
                <Radio value="货到付款">货到付款</Radio>
              </Radio.Group>
            </Form.Item>
          </Card>

          {/* 备注 */}
          <Card style={{ marginBottom: '20px' }}>
            <Form.Item name="remark" label="订单备注">
              <TextArea rows={3} placeholder="选填，对本次购买的说明" />
            </Form.Item>
          </Card>

          {/* 订单汇总 */}
          <Card>
            <div style={{ 
              textAlign: isMobile ? 'left' : 'right', 
              marginBottom: '20px' 
            }}>
              <Space 
                size="large" 
                direction={isMobile ? 'vertical' : 'horizontal'}
                style={{ width: '100%' }}
              >
                <div>
                  <span style={{ fontSize: isMobile ? '14px' : '16px' }}>
                    商品总计：¥{calculateTotal().toFixed(2)}
                  </span>
                </div>
                <div>
                  <Title level={isMobile ? 5 : 4} style={{ margin: 0 }}>
                    实付：<span style={{ color: '#ff4d4f', fontSize: isMobile ? '18px' : '24px' }}>
                      ¥{calculateTotal().toFixed(2)}
                    </span>
                  </Title>
                </div>
              </Space>
            </div>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                size={isMobile ? 'middle' : 'large'}
                loading={submitting}
                block
              >
                提交订单
              </Button>
            </Form.Item>
          </Card>
        </Form>
      </Card>

      {/* 移动端底部导航 */}
      <div style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#fff',
        borderTop: '1px solid #f0f0f0',
        zIndex: 999,
        display: isMobile ? 'flex' : 'none',
        justifyContent: 'space-around',
        alignItems: 'center',
        padding: '10px 0',
        boxShadow: '0 -2px 10px rgba(0,0,0,0.1)',
        boxSizing: 'border-box'
      }}>
        {commonMenuConfig.map(item => (
          <div
            key={item.key}
            style={{
              textAlign: 'center',
              flex: 1,
              cursor: 'pointer',
              color: item.isActive(location.pathname) ? '#1890ff' : '#666',
              fontWeight: item.isActive(location.pathname) ? 'bold' : 'normal',
              transition: 'color 0.2s ease'
            }}
            onClick={() => {
              window.scrollTo({ top: 0, behavior: 'smooth' });
              navigate(item.path);
            }}
          >
            <div style={{ fontSize: '20px', marginBottom: '4px' }}>
              {item.key === 'cart' ? <Badge count={cartCount} showZero>{item.icon}</Badge> : item.icon}
            </div>
            <div style={{ fontSize: '12px' }}>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Order;

