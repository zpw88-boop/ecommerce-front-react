import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Button, InputNumber, message, Spin, Tag, Descriptions, Image } from 'antd';
import { ShoppingCartOutlined, PlusOutlined, MinusOutlined } from '@ant-design/icons';
import { getProductDetail } from '../api/front/productApi';
import { addToCart } from '../api/front/cartApi';

function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [imageIndex, setImageIndex] = useState(0);

  // 获取商品详情
  const fetchProductDetail = async () => {
    setLoading(true);
    try {
      const res = await getProductDetail(id);
      if (res.code === 200) {
        setProduct(res.data);
      } else {
        message.error(res.msg || '获取商品详情失败');
        navigate('/products');
      }
    } catch (err) {
      message.error('获取商品详情失败');
      navigate('/products');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      fetchProductDetail();
    }
  }, [id]);

  // 加入购物车
  const handleAddToCart = async () => {
    if (!product) return;

    const isLoggedIn = !!localStorage.getItem('token');
    
    if (!isLoggedIn) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }

    try {
      const res = await addToCart({
        goodsId: product.id,
        goodsName: product.goodsName || product.goods_name || product.name || '',
        goodsPrice: product.goodsPrice || product.goods_price || 0,
        goodsImg: product.goodsImg || product.goods_img || product.img || '',
        warehouseId: product.warehouseId || product.warehouse_id || product.warehouse?.id || '',
        quantity: quantity
      });

      if (res.code === 200) {
        message.success('已加入购物车');
        // 更新Header中的购物车数量
        window.dispatchEvent(new Event('cartUpdated'));
      } else {
        message.error(res.msg || '加入购物车失败');
      }
    } catch (err) {
      message.error('加入购物车失败');
    }
  };

  // 立即购买
  const handleBuyNow = () => {
    if (!product) return;

    const isLoggedIn = !!localStorage.getItem('token');
    
    if (!isLoggedIn) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }

    // 跳转到订单页面，传递商品信息
    navigate(`/order?goodsId=${product.id}&quantity=${quantity}`);
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '100px' }}>
        <Spin size="large" />
      </div>
    );
  }

  if (!product) {
    return null;
  }

  // 商品图片列表（可以后续扩展为多图）
  const images = product.goodsImg ? [product.goodsImg] : [];

  return (
    <div style={{ padding: '20px 50px', background: '#f5f5f5', minHeight: 'calc(100vh - 80px)' }}>
      <Card>
        <div style={{ display: 'flex', gap: '40px', flexWrap: 'wrap' }}>
          {/* 商品图片 */}
          <div style={{ flex: '0 0 400px' }}>
            {images.length > 0 ? (
              <Image
                src={images[imageIndex]}
                alt={product.goodsName}
                style={{ width: '100%', borderRadius: '8px' }}
                preview={{
                  mask: '预览'
                }}
              />
            ) : (
              <div
                style={{
                  width: '100%',
                  height: '400px',
                  background: '#f0f0f0',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: '8px'
                }}
              >
                暂无图片
              </div>
            )}
            {images.length > 1 && (
              <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
                {images.map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`${product.goodsName}-${index}`}
                    style={{
                      width: '60px',
                      height: '60px',
                      objectFit: 'cover',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      border: imageIndex === index ? '2px solid #1890ff' : '1px solid #d9d9d9'
                    }}
                    onClick={() => setImageIndex(index)}
                  />
                ))}
              </div>
            )}
          </div>

          {/* 商品信息 */}
          <div style={{ flex: '1', minWidth: '300px' }}>
            <h1 style={{ fontSize: '24px', marginBottom: '16px' }}>{product.goodsName}</h1>
            
            <div style={{ marginBottom: '24px' }}>
              <span style={{ fontSize: '32px', color: '#ff4d4f', fontWeight: 'bold' }}>
                ¥{Number(product.goodsPrice || 0).toFixed(2)}
              </span>
            </div>

            <Descriptions column={1} style={{ marginBottom: '24px' }}>
              <Descriptions.Item label="商品编号">{product.id}</Descriptions.Item>
              {product.barCode && (
                <Descriptions.Item label="条形码">{product.barCode}</Descriptions.Item>
              )}
              <Descriptions.Item label="库存">
                <Tag color={product.stock > 0 ? 'success' : 'error'}>
                  {product.stock > 0 ? `有货 (${product.stock})` : '缺货'}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="状态">
                <Tag color={product.status === 1 ? 'success' : 'default'}>
                  {product.status === 1 ? '在售' : '已下架'}
                </Tag>
              </Descriptions.Item>
            </Descriptions>

            {/* 购买数量 */}
            <div style={{ marginBottom: '24px' }}>
              <span style={{ marginRight: '16px' }}>购买数量：</span>
              <InputNumber
                min={1}
                max={product.stock || 999}
                value={quantity}
                onChange={setQuantity}
                addonBefore={<MinusOutlined onClick={() => setQuantity(Math.max(1, quantity - 1))} />}
                addonAfter={<PlusOutlined onClick={() => setQuantity(Math.min(product.stock || 999, quantity + 1))} />}
              />
            </div>

            {/* 操作按钮 */}
            <div style={{ display: 'flex', gap: '16px' }}>
              <Button
                type="primary"
                size="large"
                icon={<ShoppingCartOutlined />}
                onClick={handleAddToCart}
                disabled={product.status !== 1 || product.stock === 0}
              >
                加入购物车
              </Button>
              <Button
                type="primary"
                danger
                size="large"
                onClick={handleBuyNow}
                disabled={product.status !== 1 || product.stock === 0}
              >
                立即购买
              </Button>
            </div>
          </div>
        </div>

        {/* 商品详情（可以后续扩展） */}
        <div style={{ marginTop: '40px', padding: '20px', background: '#fff', borderRadius: '8px' }}>
          <h2>商品详情</h2>
          <div style={{ marginTop: '16px', color: '#666' }}>
            {product.description || '暂无商品详情'}
          </div>
        </div>
      </Card>
    </div>
  );
}

export default ProductDetail;

