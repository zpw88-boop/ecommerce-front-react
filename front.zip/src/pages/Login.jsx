import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Form, Input, Button, Card, message } from 'antd';
import { LockOutlined, UserOutlined } from '@ant-design/icons';
import { login } from '../api/front/userApi';

const Login = () => {
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();
    const [form] = Form.useForm();

    const handleLogin = async (values) => {
        setLoading(true);
        try {
            const res = await login({
                username: values.username,
                password: values.password,
                userType: 1
            });

            if (res.code === 200) {
                // 处理不同的响应数据结构
                // 可能的情况：
                // 1. res.data 包含用户信息
                // 2. res 直接包含用户信息（token 在顶层）
                const userData = res.data || res;
                
                // 检查 token 是否存在
                const token = userData.token || res.token;
                if (!token) {
                    message.error('登录失败：未获取到认证令牌');
                    setLoading(false);
                    return;
                }

                const userInfo = {
                    token: token,
                    userId: userData.userId || userData.user_id || res.userId || res.user_id,
                    username: userData.username || res.username || values.username,
                    nickname: userData.nickname || res.nickname,
                    avatar: userData.avatar || res.avatar,
                    userType: userData.userType || userData.user_type || res.userType || res.user_type || 1,
                    role: userData.role || res.role,
                    status: userData.status || res.status,
                    expiresIn: userData.expiresIn || userData.expires_in || res.expiresIn || res.expires_in
                };

                // 存储 token 和用户信息
                localStorage.setItem('token', userInfo.token);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                
                message.success(res.msg || '登录成功');

                // 跳转到首页
                setTimeout(() => {
                    navigate('/', { replace: true });
                    // 触发购物车更新事件
                    window.dispatchEvent(new Event('cartUpdated'));
                    // 触发用户信息更新事件
                    window.dispatchEvent(new Event('userInfoUpdated'));
                }, 500);
            } else {
                message.error(res.msg || '登录失败，请检查账号密码');
            }
        } catch (err) {
            if (err.response) {
                // 后端返回的错误响应
                const errorData = err.response.data;
                // 后端Result格式：{ code, msg, data }
                const errorMsg = errorData?.msg || errorData?.message || '登录失败，请检查账号密码';
                message.error(errorMsg);
            } else if (err.request) {
                // 请求已发送但没有收到响应
                message.error('网络异常，请检查后端服务是否启动（http://localhost:8080）');
            } else {
                // 请求配置错误
                message.error('登录异常，请稍后再试');
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            background: '#f0f2f5'
        }}>
            <Card title="用户登录" style={{ width: 400 }}>
                <Form
                    form={form}
                    name="login_form"
                    onFinish={handleLogin}
                    layout="vertical"
                >
                    <Form.Item
                        name="username"
                        label="用户名"
                        rules={[{ required: true, message: '请输入用户名' }]}
                    >
                        <Input
                            prefix={<UserOutlined />}
                            placeholder="请输入用户名"
                        />
                    </Form.Item>

                    <Form.Item
                        name="password"
                        label="密码"
                        rules={[{ required: true, message: '请输入密码' }]}
                    >
                        <Input.Password
                            prefix={<LockOutlined />}
                            placeholder="请输入密码"
                        />
                    </Form.Item>

                    <Form.Item>
                        <Button
                            type="primary"
                            htmlType="submit"
                            loading={loading}
                            block
                            size="large"
                        >
                            登录
                        </Button>
                    </Form.Item>

                    <Form.Item style={{ marginBottom: 0, textAlign: 'center' }}>
                        <Button type="link" onClick={() => navigate('/register')}>
                            还没有账号？去注册
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
};

export default Login;