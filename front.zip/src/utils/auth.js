/**
 * JWT认证工具函数
 * 统一管理用户登录状态和用户信息的获取
 */

/**
 * 检查用户是否已登录
 * @returns {boolean} 是否已登录
 */
export const isLoggedIn = () => {
  return !!localStorage.getItem('token');
};

/**
 * 获取用户信息（从localStorage）
 * @returns {Object} 用户信息对象
 */
export const getUserInfo = () => {
  try {
    return JSON.parse(localStorage.getItem('userInfo') || '{}');
  } catch (err) {
    return {};
  }
};

/**
 * 获取用户ID（兼容 userId 和 user_id 字段）
 * @returns {number|null} 用户ID，如果不存在则返回null
 */
export const getUserId = () => {
  const userInfo = getUserInfo();
  return userInfo.userId || userInfo.user_id || null;
};

/**
 * 获取Token
 * @returns {string|null} Token字符串，如果不存在则返回null
 */
export const getToken = () => {
  return localStorage.getItem('token');
};

/**
 * 清除用户信息（登出时使用）
 */
export const clearUserInfo = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('userInfo');
};

/**
 * 设置用户信息（登录时使用）
 * @param {Object} userData - 后端返回的用户数据
 */
export const setUserInfo = (userData) => {
  const userInfo = {
    token: userData.token,
    userId: userData.userId || userData.user_id,
    username: userData.username,
    nickname: userData.nickname,
    avatar: userData.avatar,
    userType: userData.userType || userData.user_type || 1,
    role: userData.role,
    status: userData.status,
    expiresIn: userData.expiresIn || userData.expires_in
  };

  localStorage.setItem('token', userInfo.token);
  localStorage.setItem('userInfo', JSON.stringify(userInfo));
  
  return userInfo;
};

