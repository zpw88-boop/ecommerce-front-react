import axios from 'axios';
import { message } from 'antd';

// 创建axios实例
const request = axios.create({
    baseURL: 'http://localhost:8080', 
    timeout: 5000,
    withCredentials: true,
});

// 请求拦截器：根据后端 @NoAuth 注解，对公开接口不携带 Token
request.interceptors.request.use(
    (config) => {
        // 不需要 Token 的公开接口列表（对应后端 @NoAuth 注解的接口）
        const publicPaths = ['/api/auth/login', '/api/auth/register'];
        const isPublicPath = publicPaths.some(path => config.url?.includes(path));
        
        // 只有非公开接口且存在 token 时才添加 Authorization 头
        const token = localStorage.getItem('token');
        if (token && !isPublicPath) {
            // 格式：Bearer + 英文空格 + Token（后端 JWT 过滤器期望的格式）
            config.headers.Authorization = `Bearer ${token}`;
        }

        // 为 POST/PUT/PATCH 请求设置 Content-Type
        if (config.method === 'post' || config.method === 'put' || config.method === 'patch') {
            if (!config.headers['Content-Type']) {
                config.headers['Content-Type'] = 'application/json';
            }
        }

        return config;
    },
    (error) => Promise.reject(error)
);

// 响应拦截器：统一处理错误响应
request.interceptors.response.use(
    response => response.data, // 直接返回接口数据
    (error) => {
        if (error.response) {
            const errorData = error.response.data;
            const errorMsg = errorData?.msg || errorData?.message;
            
            // 401：Token 无效/过期
            if (error.response.status === 401) {
                localStorage.removeItem('token');
                localStorage.removeItem('userInfo');
                if (errorMsg) {
                    message.error(errorMsg);
                } else {
                    message.error('登录凭证失效，请重新登录');
                }
                window.location.href = '/login';
            } 
            // 403：访问被拒绝（权限不足）
            else if (error.response.status === 403) {
                // 在控制台输出详细信息，帮助调试
                const requestUrl = error.config?.url || '未知接口';
                const requestMethod = error.config?.method?.toUpperCase() || '未知';
                console.error('403错误详情：', {
                    url: requestUrl,
                    method: requestMethod,
                    status: error.response.status,
                    statusText: error.response.statusText,
                    responseData: error.response.data,
                    headers: error.config?.headers
                });
                
                if (errorMsg) {
                    message.error(errorMsg);
                } else {
                    // 显示更详细的错误信息，包括请求的 URL，帮助定位问题
                    message.error(`访问被拒绝（403）：${requestMethod} ${requestUrl}，请检查接口路径或联系管理员`);
                }
            }
            // 404：接口不存在
            else if (error.response.status === 404) {
                if (errorMsg) {
                    message.error(errorMsg);
                } else {
                    message.error(`业务接口不存在：${error.config.url}`);
                }
            }
            // 500：后端服务异常
            else if (error.response.status === 500) {
                if (errorMsg) {
                    message.error(errorMsg);
                } else {
                    message.error('后端服务异常，请联系管理员');
                }
            }
            // 其他错误：显示后端返回的错误信息
            else if (errorMsg) {
                message.error(errorMsg);
            }
        } else if (error.request) {
            // 网络错误：后端服务未启动或网络异常
            message.error('网络异常，请检查后端服务是否启动（http://localhost:8080）');
        }

        return Promise.reject(error);
    }
);

export default request;