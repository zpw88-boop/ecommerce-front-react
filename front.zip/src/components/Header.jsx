import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Layout, Button, Badge, Dropdown, Space, Avatar, message } from 'antd';
import { getUserId, getUserInfo, isLoggedIn } from '../utils/auth';
import {
  ShoppingCartOutlined,
  UserOutlined,
  LogoutOutlined,
  HomeOutlined,
  ShoppingOutlined
} from '@ant-design/icons';
import { getCartList } from '../api/front/cartApi';
import './Header.css';

const { Header: AntHeader } = Layout;

export const commonMenuConfig = [
  {
    key: 'home',
    icon: <HomeOutlined />,
    label: '首页',
    path: '/',
    isActive: (currentPath) => currentPath === '/'
  },
  {
    key: 'cart',
    icon: <ShoppingCartOutlined />,
    label: '购物车',
    path: '/cart',
    isActive: (currentPath) => currentPath === '/cart'
  },
  {
    key: 'user',
    icon: <UserOutlined />,
    label: '个人中心',
    path: '/profile',
    isActive: (currentPath) => ['/profile', '/orders'].includes(currentPath)
  }
];

function Header() {
  // 仅使用路由钩子，无 Router 包裹
  const navigate = useNavigate();
  const location = useLocation();
  const [cartCount, setCartCount] = useState(0);
  const [loggedIn, setLoggedIn] = useState(isLoggedIn());
  const [userInfo, setUserInfoState] = useState(getUserInfo());

  const fetchCartCount = async () => {
    if (!loggedIn) {
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(localCart.length);
      return;
    }
    try {
      const userId = getUserId();
      if (!userId) {
        return;
      }
      const res = await getCartList(userId);
      if (res.code === 200) {
        // 
        const count = res.data?.reduce((sum, item) => sum + (item.num || 0), 0) || 0;
        setCartCount(count);
      }
    } catch (err) {
    }
  };

  const handleMenuNavigate = (path) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(path);
  };

  useEffect(() => {
    setLoggedIn(isLoggedIn());
    setUserInfoState(getUserInfo());
    fetchCartCount();

    const handleCartUpdate = () => {
      fetchCartCount();
    };
    
    const handleUserInfoUpdate = () => {
      const newLoggedIn = isLoggedIn();
      setLoggedIn(newLoggedIn);
      setUserInfoState(getUserInfo());
      if (newLoggedIn) {
        fetchCartCount();
      }
    };

    window.addEventListener('cartUpdated', handleCartUpdate);
    window.addEventListener('userInfoUpdated', handleUserInfoUpdate);

    return () => {
      window.removeEventListener('cartUpdated', handleCartUpdate);
      window.removeEventListener('userInfoUpdated', handleUserInfoUpdate);
    };
  }, [location.pathname]);

  const userMenuItems = loggedIn
    ? [
        {
          key: 'profile',
          label: '个人中心',
          icon: <UserOutlined />,
          onClick: () => handleMenuNavigate('/profile')
        },
        {
          key: 'orders',
          label: '我的订单',
          onClick: () => handleMenuNavigate('/orders')
        },
        {
          type: 'divider'
        },
        {
          key: 'logout',
          label: '退出登录',
          icon: <LogoutOutlined />,
          danger: true,
          onClick: () => {
            localStorage.removeItem('token');
            localStorage.removeItem('userInfo');
            setLoggedIn(false);
            message.success('已退出登录');
            handleMenuNavigate('/');
          }
        }
      ]
    : [
        {
          key: 'login',
          label: '登录',
          onClick: () => handleMenuNavigate('/login')
        },
        {
          key: 'register',
          label: '注册',
          onClick: () => handleMenuNavigate('/register')
        }
      ];

  return (
    <AntHeader
      style={{
        background: '#fff',
        padding: '0 50px',
        height: '80px',
        lineHeight: '80px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
        position: 'sticky',
        top: 0,
        zIndex: 1000,
        width: '100%',
        boxSizing: 'border-box'
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          cursor: 'pointer'
        }}
        onClick={() => handleMenuNavigate(commonMenuConfig[0].path)}
      >
        <HomeOutlined style={{ fontSize: '24px', color: '#1890ff', marginRight: '8px' }} />
        <span style={{ fontSize: '20px', fontWeight: 'bold', color: '#1890ff' }}>
          kingso跨境电商
        </span>
      </div>

      <Space size="large" className="header-right-menu">
        {/* 购物车按钮 - 移动端隐藏 */}
        <Badge count={cartCount} showZero className="header-menu-item">
          <Button
            type="text"
            icon={commonMenuConfig[1].icon}
            onClick={() => handleMenuNavigate(commonMenuConfig[1].path)}
            style={{
              fontSize: '16px',
              color: commonMenuConfig[1].isActive(location.pathname) ? '#1890ff' : '#666',
              fontWeight: commonMenuConfig[1].isActive(location.pathname) ? 'bold' : 'normal'
            }}
          >
            {commonMenuConfig[1].label}
          </Button>
        </Badge>

        {/* 个人中心/登录注册 - 移动端隐藏 */}
        <div className="header-menu-item">
          {loggedIn ? (
            <Dropdown menu={{ items: userMenuItems }} placement="bottomRight">
              <Space
                style={{
                  cursor: 'pointer',
                  color: commonMenuConfig[2].isActive(location.pathname) ? '#1890ff' : '#666'
                }}
              >
                <Avatar icon={<UserOutlined />} src={userInfo.avatar} />
                <span>{userInfo.nickname || userInfo.username || '用户'}</span>
              </Space>
            </Dropdown>
          ) : (
            <Space>
              <Button type="text" onClick={() => handleMenuNavigate('/login')}>
                登录
              </Button>
              <Button type="primary" onClick={() => handleMenuNavigate('/register')}>
                注册
              </Button>
            </Space>
          )}
        </div>
      </Space>
    </AntHeader>
  );
}

export default Header;