import request from '../../utils/request';

/**
 * 分页查询商品
 * 对应后端：GoodsFrontController @GetMapping("/page")
 * 接口路径：/api/front/goods/page
 * @param params 查询参数（pageNum, pageSize, status, goodsName, categoryId, minPrice, maxPrice, warehouseId等）
 */
export const getGoodsPage = (params) => {
  return request.get('/api/front/goods/page', { params });
};

/**
 * 查询商品详情
 * 注意：GoodsFrontController 中没有提供详情接口
 * 根据 GoodsFrontController 的结构，如果添加详情接口，路径应该是 /api/front/goods/{id}
 * 如果前台没有详情接口，可能需要使用后台管理接口 /api/admin/goods/{id}（需要管理员权限）
 * 
 * 当前尝试使用前台路径：/api/front/goods/{id}
 * 如果返回 404，说明前台没有详情接口，需要后端添加或使用后台接口
 * @param id 商品ID
 */
export const getProductDetail = (id) => {
  // 先尝试使用前台路径（如果后端有提供）
  return request.get(`/api/front/goods/${id}`);
};

