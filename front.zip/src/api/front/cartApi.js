import request from '../../utils/request';

export const getCartList = (userId) => {
  if (!userId) {
    return Promise.resolve({ code: 200, data: [] });
  }
  // 后端接口：@GetMapping("/list/{userId}")，使用路径变量
  return request.get(`/cart/list/${userId}`);
};

export const addToCart = (data) => {
  const userId = data.userId;
  if (!userId) {
    return Promise.reject(new Error('用户未登录'));
  }
  const requestData = {
    userId: data.userId,
    goodsId: data.goodsId,
    goodsName: data.goodsName || '',
    goodsPrice: data.goodsPrice,
    goodsImg: data.goodsImg,
    warehouseId: data.warehouseId || '',
    num: data.num || data.quantity || 1
  };
  // 后端接口：@PostMapping("/add")
  return request.post('/cart/add', requestData);
};

export const updateCartItem = (data) => {
  // 后端接口：@PutMapping("/update/num")
  return request.put('/cart/update/num', data);
};

export const deleteCartItem = (data) => {
  // 后端接口：@DeleteMapping("/delete")
  return request.delete('/cart/delete', { data });
};

