import request from '../../utils/request';

/**
 * 创建订单
 * 对应后端：OrderFrontController @PostMapping("/add")
 * 接口路径：/api/front/order/add
 */
export const createOrder = (data) => {
  return request.post('/api/front/order/add', data);
};

/**
 * 分页查询订单列表
 * 对应后端：OrderFrontController @GetMapping("/page")
 * 接口路径：/api/front/order/page
 * @param params 查询参数（OrderQueryDTO）
 */
export const getOrderList = (params) => {
  return request.get('/api/front/order/page', { params });
};

/**
 * 根据ID查询订单（不含明细）
 * 对应后端：OrderFrontController @GetMapping("/{id}")
 * 接口路径：/api/front/order/{id}
 * @param id 订单ID（路径变量）
 */
export const getOrderById = (id) => {
  return request.get(`/api/front/order/${id}`);
};

/**
 * 根据ID查询订单及明细（关联查询）
 * 对应后端：OrderFrontController @GetMapping("/withItem/{id}")
 * 接口路径：/api/front/order/withItem/{id}
 * @param id 订单ID（路径变量）
 */
export const getOrderWithItem = (id) => {
  return request.get(`/api/front/order/withItem/${id}`);
};

/**
 * 根据订单编号查询订单
 * 对应后端：OrderFrontController @GetMapping("/orderNo/{orderNo}")
 * 接口路径：/api/front/order/orderNo/{orderNo}
 * @param orderNo 订单编号（路径变量）
 */
export const getOrderByOrderNo = (orderNo) => {
  return request.get(`/api/front/order/orderNo/${orderNo}`);
};

/**
 * 取消订单
 * 
 * @param id 订单ID
 */
export const cancelOrder = (id) => {
  // 暂时保留，如果后端有对应接口请告知路径
  return request.put(`/api/front/order/cancel/${id}`);
};

/**
 * 确认收货
 * 
 * @param id 订单ID
 */
export const confirmOrder = (id) => {
  // 
  return request.put(`/api/front/order/confirm/${id}`);
};

/**
 * 删除订单
 * 
 * @param id 订单ID
 */
export const deleteOrder = (id) => {
  // 暂时保留，如果后端有对应接口请告知路径
  return request.delete(`/api/front/order/delete/${id}`);
};

