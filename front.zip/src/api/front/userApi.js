import request from '../../utils/request';

/**
 * 用户登录
 * 对应后端：LoginController @PostMapping("/login")
 * 接口路径：/api/auth/login
 */
export const login = (data) => {
  return request.post('/api/auth/login', data);
};

/**
 * 用户注册
 * 对应后端：UserFrontController @PostMapping("/register")
 * 接口路径：/api/userfront/register
 */
export const register = (data) => {
  return request.post('/api/userfront/register', data);
};

/**
 * 获取当前登录用户信息
 * 对应后端：UserFrontController @GetMapping("/info")
 * 接口路径：/api/userfront/info
 */
export const getCurrentUserInfo = () => {
  return request.get('/api/userfront/info');
};

/**
 * 根据用户ID获取用户信息
 * 对应后端：UserFrontController @GetMapping("/{userId}")
 * 接口路径：/api/userfront/{userId}
 * @param userId 用户ID（路径变量）
 */
export const getUserInfo = (userId) => {
  return request.get(`/api/userfront/${userId}`);
};

/**
 * 更新个人信息
 * 对应后端：UserFrontController @PutMapping("/update/self")
 * 接口路径：/api/userfront/update/self
 */
export const updateUserInfo = (data) => {
  return request.put('/api/userfront/update/self', data);
};


