import React, { useState } from 'react';
import { Card, Button, InputNumber, message, Row, Col, Typography, Tag, Modal } from 'antd';
import { ShoppingCartOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { addToCart } from '../api/front/cartApi';
import { getUserId } from '../utils/auth';
import './ProductListCard.css';

const { Text } = Typography;

function ProductListCard({ product }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = async () => {
    // 检查商品状态
    if (product.status !== 1) {
      message.warning('商品已下架');
      return;
    }

    // 获取仓库库存数据（优先检查仓库库存）
    const warehouseStock = product.warehouseStock || product.warehouse_stock || product.warehouse?.stock || null;
    const totalStock = product.stock || product.availableStock || product.available_stock || 0;
    
    // 如果存在仓库库存数据，必须使用仓库库存进行验证
    if (warehouseStock !== null && warehouseStock !== undefined) {
      if (warehouseStock === 0) {
        message.warning('该仓库商品库存不足');
        return;
      }
      
      // 数量必须小于等于仓库库存
      if (quantity > warehouseStock) {
        message.warning(`购买数量不能大于仓库库存（当前仓库库存：${warehouseStock}）`);
        return;
      }
    } else {
      // 如果没有仓库库存数据，使用总库存进行验证
      if (totalStock === 0) {
        message.warning('商品库存不足');
        return;
      }
      
      // 数量必须小于等于总库存
      if (quantity > totalStock) {
        message.warning(`购买数量不能大于库存数量（当前库存：${totalStock}）`);
        return;
      }
    }

    // 检查登录状态
    const isLoggedIn = !!localStorage.getItem('token');
    if (!isLoggedIn) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }

    // 获取用户ID
    const userId = getUserId();

    if (!userId) {
      message.error('用户信息获取失败，请重新登录');
      navigate('/login');
      return;
    }

    // 获取商品ID
    const goodsId = product.goodsId || product.goods_id || product.id;
    if (!goodsId) {
      message.error('商品ID获取失败，请检查商品数据');
      return;
    }

    // 获取商品价格
    const goodsPrice = product.goodsPrice || product.goods_price || 0;
    if (!goodsPrice || goodsPrice <= 0) {
      message.warning('商品价格无效');
      return;
    }

    // 获取商品图片
    const goodsImg = product.goodsImg || product.goods_img || product.img || '';
    if (!goodsImg) {
      message.warning('商品图片缺失');
      return;
    }

    // 获取商品名称
    const goodsName = product.goodsName || product.goods_name || product.name || '';
    if (!goodsName) {
      message.warning('商品名称缺失');
      return;
    }

    // 获取仓库ID
    const warehouseId = product.warehouseId || product.warehouse_id || product.warehouse?.id || '';

    // 获取数量（页面录入的数量）
    const num = quantity;
    if (!num || num <= 0) {
      message.warning('购买数量必须大于0');
      return;
    }

    // 准备提交的数据
    const cartData = {
      userId: userId,
      goodsId: goodsId,
      goodsName: goodsName,
      goodsPrice: goodsPrice,
      goodsImg: goodsImg,
      warehouseId: warehouseId,
      num: num
    };

    // 提交到后端
    setLoading(true);
    try {
      const res = await addToCart(cartData);

      if (res.code === 200) {
        message.success('已加入购物车');
        // 触发购物车更新事件
        window.dispatchEvent(new Event('cartUpdated'));
        setQuantity(1); // 重置数量
      } else {
        const errorMsg = res.msg || res.message || '加入购物车失败';
        message.error(errorMsg);
      }
    } catch (err) {
      if (err.response?.data) {
        const errorData = err.response.data;
        const errorMsg = errorData.msg || errorData.message || '加入购物车失败';
        message.error(errorMsg);
      } else if (err.message) {
        message.error(`加入购物车失败：${err.message}`);
      } else {
        message.error('加入购物车失败，请检查网络连接');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleImageClick = () => {
    navigate(`/products/${product.id}`);
  };

  return (
    <Card
      className="product-list-card"
      style={{ marginBottom: '16px' }}
      hoverable
    >
      <Row gutter={16} align="middle">
        {/* 左侧：商品图片 */}
        <Col xs={24} sm={8} md={6} lg={5} xl={4}>
          <div
            className="product-image-container"
            onClick={handleImageClick}
          >
            {product.goodsImg ? (
              <img
                alt={product.goodsName}
                src={product.goodsImg}
                className="product-image"
              />
            ) : (
              <div style={{ color: '#999' }}>暂无图片</div>
            )}
          </div>
        </Col>

        {/* 右侧：商品信息 */}
        <Col xs={24} sm={16} md={18} lg={19} xl={20}>
          {/* 商品名称 - 单独一行 */}
          <div style={{ marginBottom: '12px' }}>
            <Text
              strong
              style={{ fontSize: '16px', cursor: 'pointer' }}
              onClick={handleImageClick}
              ellipsis={{ tooltip: product.goodsName }}
            >
              {product.goodsName}
            </Text>
          </div>

          {/* 其他信息 - 一行 */}
          <Row gutter={[16, 8]} align="middle">
            {/* 商品价格 */}
            <Col xs={12} sm={6} md={4} lg={4} xl={4}>
              <div>
                <Text type="secondary" style={{ fontSize: '12px' }}>价格</Text>
                <div>
                  <Text type="danger" style={{ fontSize: '20px', fontWeight: 'bold' }}>
                    ¥{Number(product.goodsPrice || 0).toFixed(2)}
                  </Text>
                </div>
              </div>
            </Col>

            {/* 商品发货仓库 */}
            <Col xs={12} sm={6} md={4} lg={4} xl={4}>
              <div>
                <Text type="secondary" style={{ fontSize: '12px' }}>发货仓库</Text>
                <div>
                  <Text>
                    {product.warehouseName || '默认仓库'}
                  </Text>
                </div>
              </div>
            </Col>

            {/* 数量填写框 */}
            <Col xs={12} sm={6} md={4} lg={4} xl={4}>
              <div>
                <Text type="secondary" style={{ fontSize: '12px' }}>数量</Text>
                <div>
                  <InputNumber
                    min={1}
                    max={(() => {
                      // 
                      const warehouseStock = product.warehouseStock || product.warehouse_stock || product.warehouse?.stock;
                      const totalStock = product.stock || product.availableStock || product.available_stock || 999;
                      return warehouseStock !== null && warehouseStock !== undefined ? warehouseStock : totalStock;
                    })()}
                    value={quantity}
                    onChange={(value) => {
                      // 确保是整数
                      if (value !== null && value !== undefined) {
                        const newQuantity = Math.floor(value);
                        
                        // 获取库存数据
                        const warehouseStock = product.warehouseStock || product.warehouse_stock || product.warehouse?.stock;
                        const totalStock = product.stock || product.availableStock || product.available_stock || 0;
                        const maxStock = warehouseStock !== null && warehouseStock !== undefined ? warehouseStock : totalStock;
                        
                        // 如果数量大于库存，弹出提示
                        if (newQuantity > maxStock && maxStock > 0) {
                          Modal.warning({
                            title: '数量超出库存',
                            content: (
                              <div>
                                <p>您输入的数量（{newQuantity}）超过了当前库存（{maxStock}）。</p>
                                <p>系统已自动调整为最大可购买数量：{maxStock}</p>
                              </div>
                            ),
                            okText: '确定',
                            onOk: () => {
                              setQuantity(maxStock);
                            }
                          });
                          setQuantity(maxStock);
                        } else {
                          setQuantity(newQuantity);
                        }
                      }
                    }}
                    precision={0}
                    style={{ width: '100%' }}
                    size="small"
                    parser={(value) => {
                      // 解析时只保留整数部分
                      return value ? Math.floor(parseFloat(value.replace(/\$\s?|(,*)/g, ''))) : '';
                    }}
                    formatter={(value) => {
                      // 格式化时只显示整数
                      return value ? Math.floor(value).toString() : '';
                    }}
                  />
                </div>
                {/* 不显示库存数量 */}
              </div>
            </Col>

            {/* 加购物车按钮 */}
            <Col xs={12} sm={6} md={4} lg={4} xl={4}>
              <div>
                <Button
                  type="primary"
                  icon={<ShoppingCartOutlined />}
                  onClick={handleAddToCart}
                  loading={loading}
                  disabled={product.status !== 1 || product.stock === 0}
                  block
                >
                  加购物车
                </Button>
              </div>
            </Col>
          </Row>

          {/* 状态标签（隐藏总数量） */}
          <div style={{ marginTop: '8px' }}>
            <Tag color={product.status === 1 ? 'success' : 'default'}>
              {product.status === 1 ? '在售' : '已下架'}
            </Tag>
            {/* 隐藏总数量，不显示库存信息 */}
          </div>
        </Col>
      </Row>
    </Card>
  );
}

export default ProductListCard;

