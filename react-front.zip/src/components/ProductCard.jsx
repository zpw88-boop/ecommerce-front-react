import React, { useState } from 'react';
import { Card, Button, Tag, Typography, message } from 'antd';
import { ShoppingCartOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import { addToCart } from '../api/front/cartApi';
import './ProductCard.css';

const { Meta } = Card;
const { Text, Title } = Typography;

function ProductCard({ product }) {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const handleAddToCart = async (e) => {
    e.stopPropagation();
    
    if (product.status !== 1) {
      message.warning('商品已下架');
      return;
    }

    if (product.stock === 0) {
      message.warning('商品库存不足');
      return;
    }

    const isLoggedIn = !!localStorage.getItem('token');
    
    if (!isLoggedIn) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }

    setLoading(true);
    try {
      const res = await addToCart({
        goodsId: product.id,
        goodsName: product.goodsName || product.goods_name || product.name || '',
        goodsPrice: product.goodsPrice || product.goods_price || 0,
        goodsImg: product.goodsImg || product.goods_img || product.img || '',
        warehouseId: product.warehouseId || product.warehouse_id || product.warehouse?.id || '',
        quantity: 1
      });

      if (res.code === 200) {
        message.success('已加入购物车');
        // 触发购物车更新事件
        window.dispatchEvent(new Event('cartUpdated'));
      } else {
        message.error(res.msg || '加入购物车失败');
      }
    } catch (err) {
      message.error('加入购物车失败');
    } finally {
      setLoading(false);
    }
  };

  const handleCardClick = () => {
    navigate(`/products/${product.id}`);
  };

  return (
    <Card
      hoverable
      style={{ width: '100%', marginBottom: '20px' }}
      cover={
        <div
          style={{
            width: '100%',
            height: '200px',
            overflow: 'hidden',
            background: '#f5f5f5',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onClick={handleCardClick}
        >
          {product.goodsImg ? (
            <img
              alt={product.goodsName}
              src={product.goodsImg}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
                cursor: 'pointer'
              }}
            />
          ) : (
            <div style={{ color: '#999' }}>暂无图片</div>
          )}
        </div>
      }
      actions={[
        <Button
          type="primary"
          icon={<ShoppingCartOutlined />}
          onClick={handleAddToCart}
          block
          loading={loading}
          disabled={product.status !== 1 || product.stock === 0}
        >
          加入购物车
        </Button>
      ]}
      onClick={handleCardClick}
    >
      <Meta
        title={
          <Title level={5} ellipsis={{ tooltip: product.goodsName }}>
            {product.goodsName}
          </Title>
        }
        description={
          <div>
            <div style={{ marginBottom: '8px' }}>
              <Text type="danger" style={{ fontSize: '20px', fontWeight: 'bold' }}>
                ¥{Number(product.goodsPrice || 0).toFixed(2)}
              </Text>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Tag color={product.status === 1 ? 'success' : 'default'}>
                {product.status === 1 ? '在售' : '已下架'}
              </Tag>
              <Text type="secondary" style={{ fontSize: '12px' }}>
                库存: {product.stock || 0}
              </Text>
            </div>
          </div>
        }
      />
    </Card>
  );
}

export default ProductCard;

