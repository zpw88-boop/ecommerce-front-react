import React, { useState, useEffect } from 'react';
import { getUserId } from '../utils/auth';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Spin,
  message,
  Card,
  Badge,
  Form,
  Input,
  Button,
  Select,
  InputNumber,
  Pagination,
  Space
} from 'antd';
import { SearchOutlined, DownOutlined, UpOutlined } from '@ant-design/icons';
import { commonMenuConfig } from '../components/Header';
import { getCartList } from '../api/front/cartApi';
import { getGoodsPage } from '../api/front/productApi';
import ProductListCard from '../components/ProductListCard';

const { Option } = Select;

function FrontHome() {
  const navigate = useNavigate();
  const location = useLocation();
  const [form] = Form.useForm();
  
  const [products, setProducts] = useState([]); // 商品列表
  const [loading, setLoading] = useState(false); // 加载状态
  const [cartCount, setCartCount] = useState(0); // 购物车数量
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768); // 判断是否为移动端
  
  // 分页相关
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);

  // 高级搜索展开状态
  const [advancedSearchVisible, setAdvancedSearchVisible] = useState(false);

  // 查询条件
  const [filters, setFilters] = useState({
    goodsName: '',
    categoryId: '',
    minPrice: '',
    maxPrice: '',
    warehouseId: ''
  });

  // 获取购物车数量
  const fetchCartCount = async () => {
    const isLoggedIn = !!localStorage.getItem('token');
    if (!isLoggedIn) {
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(localCart.length);
      return;
    }
    try {
      const userId = getUserId();
      if (!userId) {
        return;
      }
      const res = await getCartList(userId);
      if (res.code === 200) {
        const count = res.data?.reduce((sum, item) => sum + (item.num || 0), 0) || 0;
        setCartCount(count);
      }
    } catch (err) {
      // 静默处理错误，不影响页面显示
    }
  };

  // 获取商品列表
  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params = {
        pageNum: currentPage,
        pageSize: pageSize,
        status: 1, // 只显示上架商品
        ...filters
      };

      const res = await getGoodsPage(params);
      if (res.code === 200) {
        const productList = res.data?.list || [];
        setProducts(productList);
        setTotal(res.data?.total || 0);
      } else {
        message.error(res.msg || '获取商品列表失败');
      }
    } catch (err) {
      message.error('获取商品列表失败');
    } finally {
      setLoading(false);
    }
  };

  // 搜索
  const handleSearch = (values) => {
    setFilters({
      goodsName: values.goodsName || '',
      categoryId: values.categoryId || '',
      minPrice: values.minPrice || '',
      maxPrice: values.maxPrice || '',
      warehouseId: values.warehouseId || ''
    });
    setCurrentPage(1);
  };

  // 重置查询条件
  const handleReset = () => {
    form.resetFields();
    setFilters({
      goodsName: '',
      categoryId: '',
      minPrice: '',
      maxPrice: '',
      warehouseId: ''
    });
    setCurrentPage(1);
  };

  const handleMenuNavigate = (path) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(path);
  };

  const handleResize = () => {
    setIsMobile(window.innerWidth < 768);
  };

  useEffect(() => {
    fetchProducts();
    fetchCartCount();

    window.addEventListener('resize', handleResize);
    const handleCartUpdate = () => fetchCartCount();
    window.addEventListener('cartUpdated', handleCartUpdate);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('cartUpdated', handleCartUpdate);
    };
  }, [currentPage, pageSize, filters]);

  return (
    <div style={{
      padding: isMobile ? '10px' : '20px 50px',
      background: '#f5f5f5',
      minHeight: 'calc(100vh - 80px)',
      paddingBottom: isMobile ? '80px' : '20px',
      boxSizing: 'border-box',
      position: 'relative'
    }}>
      {/* 查询条件 */}
      <Card 
        title="商品查询" 
        style={{ marginBottom: '20px' }}
        extra={
          <Button
            type="link"
            icon={advancedSearchVisible ? <UpOutlined /> : <DownOutlined />}
            onClick={() => setAdvancedSearchVisible(!advancedSearchVisible)}
          >
            {advancedSearchVisible ? '收起' : '高级搜索'}
          </Button>
        }
      >
        <Form
          form={form}
          layout={isMobile ? 'vertical' : 'inline'}
          onFinish={handleSearch}
        >
          {/* 基础搜索条件，商品名称 */}
          <Form.Item name="goodsName" label="商品名称">
            <Input
              placeholder="请输入商品名称"
              style={isMobile ? { width: '100%' } : { width: 200 }}
              allowClear
            />
          </Form.Item>

          <Form.Item>
            <Space>
              <Button type="primary" htmlType="submit" icon={<SearchOutlined />}>
                查询
              </Button>
              <Button onClick={handleReset}>重置</Button>
            </Space>
          </Form.Item>

          {/* 高级搜索条件，默认隐藏 */}
          {advancedSearchVisible && (
            <>
              <Form.Item name="categoryId" label="商品分类">
                <Select
                  placeholder="请选择分类"
                  style={isMobile ? { width: '100%' } : { width: 150 }}
                  allowClear
                >
                  <Option value="">全部</Option>
                </Select>
              </Form.Item>

              <Form.Item name="minPrice" label="最低价格">
                <InputNumber
                  placeholder="最低价"
                  style={isMobile ? { width: '100%' } : { width: 120 }}
                  min={0}
                  precision={2}
                  formatter={value => `¥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value.replace(/¥\s?|(,*)/g, '')}
                />
              </Form.Item>

              <Form.Item name="maxPrice" label="最高价格">
                <InputNumber
                  placeholder="最高价"
                  style={isMobile ? { width: '100%' } : { width: 120 }}
                  min={0}
                  precision={2}
                  formatter={value => `¥ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
                  parser={value => value.replace(/¥\s?|(,*)/g, '')}
                />
              </Form.Item>

              <Form.Item name="warehouseId" label="发货仓库">
                <Select
                  placeholder="请选择仓库"
                  style={isMobile ? { width: '100%' } : { width: 150 }}
                  allowClear
                >
                  <Option value="">全部</Option>
                </Select>
              </Form.Item>
            </>
          )}
        </Form>
      </Card>

      {/* 商品列表 */}
      <Card title={`商品列表（共 ${total} 条）`}>
        <Spin spinning={loading}>
          {products.length > 0 ? (
            <>
              {products.map((product) => (
                <ProductListCard key={product.id} product={product} />
              ))}
              
              {/* 分页 */}
              <div style={{ marginTop: '20px', textAlign: 'center' }}>
                <Pagination
                  current={currentPage}
                  pageSize={pageSize}
                  total={total}
                  showSizeChanger
                  showTotal={(total) => `共 ${total} 条`}
                  onChange={(page, size) => {
                    setCurrentPage(page);
                    setPageSize(size);
                  }}
                  onShowSizeChange={(current, size) => {
                    setCurrentPage(1);
                    setPageSize(size);
                  }}
                  pageSizeOptions={['10', '20', '50']}
                />
              </div>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '40px', color: '#999' }}>
              暂无商品
            </div>
          )}
        </Spin>
      </Card>

      {/* 移动端底部导航 */}
      <div style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#fff',
        borderTop: '1px solid #f0f0f0',
        zIndex: 999,
        display: isMobile ? 'flex' : 'none',
        justifyContent: 'space-around',
        alignItems: 'center',
        padding: '10px 0',
        boxShadow: '0 -2px 10px rgba(0,0,0,0.1)',
        boxSizing: 'border-box'
      }}>
        {commonMenuConfig.map(item => (
          <div
            key={item.key}
            style={{
              textAlign: 'center',
              flex: 1,
              cursor: 'pointer',
              color: item.isActive(location.pathname) ? '#1890ff' : '#666',
              fontWeight: item.isActive(location.pathname) ? 'bold' : 'normal',
              transition: 'color 0.2s ease'
            }}
            onClick={() => handleMenuNavigate(item.path)}
          >
            <div style={{ fontSize: '20px', marginBottom: '4px' }}>
              {item.key === 'cart' ? <Badge count={cartCount} showZero>{item.icon}</Badge> : item.icon}
            </div>
            <div style={{ fontSize: '12px' }}>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default FrontHome;
