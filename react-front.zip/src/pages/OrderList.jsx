import React, { useState, useEffect } from 'react';
import { Table, Tag, Button, message, Space, Modal, Card, Row, Col, Badge, Empty } from 'antd';
import { EyeOutlined, CloseCircleOutlined, DeleteOutlined, CheckCircleOutlined } from '@ant-design/icons';
import { useNavigate, useLocation } from 'react-router-dom';
import { getOrderList, cancelOrder, deleteOrder, confirmOrder } from '../api/front/orderApi';
import { getUserId } from '../utils/auth';
import { commonMenuConfig } from '../components/Header';
import './OrderList.css';

function OrderList() {
  const navigate = useNavigate();
  const location = useLocation();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [total, setTotal] = useState(0);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  // 处理菜单导航
  const handleMenuNavigate = (path) => {
    navigate(path);
  };

  // 订单状态映射
  const statusMap = {
    0: { text: '待发货', color: 'orange' },
    1: { text: '已发货', color: 'blue' },
    2: { text: '已接收', color: 'green' },
    3: { text: '已完成', color: 'success' },
    9: { text: '已取消', color: 'default' }
  };

  // 格式化日期时间
  const formatDateTime = (dateTimeStr) => {
    if (!dateTimeStr) return '-';
    try {
      const date = new Date(dateTimeStr);
      return date.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });
    } catch (err) {
      return dateTimeStr;
    }
  };

  // 获取订单列表
  const fetchOrders = async () => {
    // 先检查是否登录
    const userId = getUserId();
    if (!userId) {
      // 未登录时不显示错误，直接返回空列表
      setOrders([]);
      setTotal(0);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const res = await getOrderList({
        pageNum: currentPage,
        pageSize: pageSize,
        userId: userId
      });
      
      if (res.code === 200) {
        // 使用后台管理接口 /api/admin/order/page
        // 返回的数据结构：{ list: [], total: number }
        // list 中每条记录是订单主表和明细表JOIN的结果，需要去重，只保留订单主信息
        const rawList = res.data?.list || [];
        const orderMap = new Map();
        
        // 按订单ID去重，只保留订单主信息
        rawList.forEach((item) => {
          const orderId = item.id;
          if (!orderMap.has(orderId)) {
            orderMap.set(orderId, {
              id: item.id,
              orderNo: item.orderNo,
              totalAmount: item.totalAmount,
              receiverName: item.receiverName,
              receiverPhone: item.receiverPhone,
              receiverAddress: item.receiverAddress,
              createTime: item.createTime,
              status: item.status,
              remark: item.remark
            });
          }
        });
        
        // 转换为数组
        const orderList = Array.from(orderMap.values());
        // 过滤掉状态为 8 的订单
        const filteredOrderList = orderList.filter(order => order.status !== 8);
        setOrders(filteredOrderList);
        setTotal(filteredOrderList.length);
      } else {
        message.error(res.msg || '获取订单列表失败');
        setOrders([]);
        setTotal(0);
      }
    } catch (err) {
      // 如果是401未授权，可能是token过期，静默处理
      if (err.response?.status === 401) {
        setOrders([]);
        setTotal(0);
      } else {
        message.error('获取订单列表失败');
        setOrders([]);
        setTotal(0);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, [currentPage, pageSize]);

  // 监听窗口大小变化
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // 取消订单
  const handleCancel = (order) => {
    Modal.confirm({
      title: '确认取消订单',
      content: `确定要取消订单 ${order.orderNo} 吗？`,
      okText: '确认取消',
      cancelText: '取消',
      okType: 'danger',
      onOk: async () => {
        try {
          const res = await cancelOrder(order.id);
          if (res.code === 200) {
            message.success('订单已取消');
            fetchOrders();
          } else {
            message.error(res.msg || '取消订单失败');
          }
        } catch (err) {
          message.error('取消订单失败');
        }
      }
    });
  };

  // 确认收货（已完成）
  const handleConfirm = (order) => {
    Modal.confirm({
      title: '确认收货',
      content: `确定订单 ${order.orderNo} 已完成收货吗？`,
      okText: '确认',
      cancelText: '取消',
      okType: 'primary',
      onOk: async () => {
        try {
          const res = await confirmOrder(order.id);
          if (res.code === 200) {
            message.success('订单已完成');
            fetchOrders();
          } else {
            message.error(res.msg || '确认收货失败');
          }
        } catch (err) {
          const errorMsg = err.response?.data?.msg || err.message || '确认收货失败';
          message.error(errorMsg);
        }
      }
    });
  };

  // 删除订单
  const handleDelete = (order) => {
    Modal.confirm({
      title: '确认删除订单',
      content: `确定要删除订单 ${order.orderNo} 吗？删除后无法恢复！`,
      okText: '确认删除',
      cancelText: '取消',
      okType: 'danger',
      onOk: async () => {
        try {
          const res = await deleteOrder(order.id);
          if (res.code === 200) {
            message.success('订单已删除');
            fetchOrders();
          } else {
            message.error(res.msg || '删除订单失败');
          }
        } catch (err) {
          const errorMsg = err.response?.data?.msg || err.message || '删除订单失败';
          message.error(errorMsg);
        }
      }
    });
  };

  const columns = [
    {
      title: '订单号',
      dataIndex: 'orderNo',
      key: 'orderNo',
      width: 180,
      render: (text) => <span style={{ fontWeight: 'bold', fontSize: '13px' }}>{text}</span>
    },
    {
      title: '订单状态',
      dataIndex: 'status',
      key: 'status',
      width: 120,
      render: (status) => {
        const statusInfo = statusMap[status] || { text: '未知', color: 'default' };
        return <Tag color={statusInfo.color}>{statusInfo.text}</Tag>;
      }
    },
    {
      title: '订单金额',
      dataIndex: 'totalAmount',
      key: 'totalAmount',
      width: 120,
      align: 'right',
      render: (amount) => <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>¥{Number(amount || 0).toFixed(2)}</span>
    },
    {
      title: '收货人',
      dataIndex: 'receiverName',
      key: 'receiverName',
      width: 120
    },
    {
      title: '电话',
      dataIndex: 'receiverPhone',
      key: 'receiverPhone',
      width: 130
    },
    {
      title: '地址',
      dataIndex: 'receiverAddress',
      key: 'receiverAddress',
      width: 250,
      ellipsis: {
        showTitle: false,
      },
      render: (address) => (
        <span title={address} style={{ display: 'block', maxWidth: '250px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {address || '-'}
        </span>
      )
    },
    {
      title: '时间',
      dataIndex: 'createTime',
      key: 'createTime',
      width: 180,
      render: (time) => formatDateTime(time)
    },
    {
      title: '操作',
      key: 'action',
      width: 120,
      fixed: 'right',
      render: (_, record) => (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          <Button
            type="link"
            icon={<EyeOutlined />}
            onClick={() => navigate(`/orders/${record.id}`)}
            style={{ padding: '0', height: 'auto' }}
          >
            查看详情
          </Button>
          {record.status === 0 && (
            <Button
              type="link"
              danger
              icon={<CloseCircleOutlined />}
              onClick={() => handleCancel(record)}
              style={{ padding: '0', height: 'auto' }}
            >
              取消订单
            </Button>
          )}
          {record.status === 1 && (
            <Button
              type="link"
              icon={<CheckCircleOutlined />}
              onClick={() => handleConfirm(record)}
              style={{ padding: '0', height: 'auto', color: '#52c41a' }}
            >
              已完成
            </Button>
          )}
          {(record.status === 3 || record.status === 9) && (
            <Button
              type="link"
              danger
              icon={<DeleteOutlined />}
              onClick={() => handleDelete(record)}
              style={{ padding: '0', height: 'auto' }}
            >
              删除订单
            </Button>
          )}
        </div>
      )
    }
  ];

  // 移动端卡片式布局
  if (isMobile) {
    return (
      <div style={{ padding: '12px', minHeight: 'calc(100vh - 80px)', paddingBottom: '80px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: '40px' }}>加载中...</div>
        ) : orders.length === 0 ? (
          <Empty description="暂无订单" />
        ) : (
          <>
            {orders.map((order) => {
              return (
                <Card
                  key={order.id}
                  style={{ marginBottom: '12px' }}
                  title={
                    <div>
                      <div style={{ fontWeight: 'bold', fontSize: '13px' }}>订单号: {order.orderNo}</div>
                    </div>
                  }
                  extra={
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', alignItems: 'flex-end' }}>
                      <Button
                        type="link"
                        size="small"
                        icon={<EyeOutlined />}
                        onClick={() => navigate(`/orders/${order.id}`)}
                        style={{ padding: '0', height: 'auto' }}
                      >
                        查看详情
                      </Button>
                        {order.status === 0 && (
                        <Button
                          type="link"
                          danger
                          size="small"
                          icon={<CloseCircleOutlined />}
                          onClick={() => handleCancel(order)}
                          style={{ padding: '0', height: 'auto' }}
                        >
                          取消订单
                        </Button>
                      )}
                      {order.status === 1 && (
                        <Button
                          type="link"
                          size="small"
                          icon={<CheckCircleOutlined />}
                          onClick={() => handleConfirm(order)}
                          style={{ padding: '0', height: 'auto', color: '#52c41a' }}
                        >
                          已完成
                        </Button>
                      )}
                      {(order.status === 3 || order.status === 9) && (
                        <Button
                          type="link"
                          danger
                          size="small"
                          icon={<DeleteOutlined />}
                          onClick={() => handleDelete(order)}
                          style={{ padding: '0', height: 'auto' }}
                        >
                          删除订单
                        </Button>
                      )}
                    </div>
                  }
                >
                  <div style={{ fontSize: '14px' }}>
                    <Row gutter={[8, 8]}>
                      <Col span={12}>
                        <div style={{ color: '#999' }}>订单金额:</div>
                        <div style={{ color: '#ff4d4f', fontWeight: 'bold', fontSize: '16px' }}>
                          ¥{Number(order.totalAmount || 0).toFixed(2)}
                        </div>
                      </Col>
                      <Col span={12}>
                        <div style={{ color: '#999' }}>订单状态:</div>
                        <div>
                          <Tag color={statusMap[order.status]?.color || 'default'}>
                            {statusMap[order.status]?.text || '未知'}
                          </Tag>
                        </div>
                      </Col>
                      <Col span={12}>
                        <div style={{ color: '#999' }}>时间:</div>
                        <div>{formatDateTime(order.createTime)}</div>
                      </Col>
                      <Col span={24}>
                        <div style={{ color: '#999' }}>收货人:</div>
                        <div>{order.receiverName || '-'}</div>
                      </Col>
                      <Col span={24}>
                        <div style={{ color: '#999' }}>电话:</div>
                        <div>{order.receiverPhone || '-'}</div>
                      </Col>
                      <Col span={24}>
                        <div style={{ color: '#999' }}>地址:</div>
                        <div>{order.receiverAddress || '-'}</div>
                      </Col>
                    </Row>
                  </div>
                </Card>
              );
            })}
            <div style={{ marginTop: '16px', textAlign: 'center' }}>
              <Space>
                <Button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                >
                  上一页
                </Button>
                <span>
                  第 {currentPage} / {Math.ceil(total / pageSize)} 页
                </span>
                <Button
                  disabled={currentPage >= Math.ceil(total / pageSize)}
                  onClick={() => setCurrentPage(currentPage + 1)}
                >
                  下一页
                </Button>
              </Space>
            </div>
          </>
        )}

        {/* 移动端底部导航 */}
        <div
          style={{
            position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            background: '#fff',
            borderTop: '1px solid #e8e8e8',
            padding: '10px 0',
            zIndex: 1000,
            display: 'flex',
            justifyContent: 'space-around',
            boxShadow: '0 -2px 8px rgba(0,0,0,0.1)'
          }}
        >
          {commonMenuConfig.map(item => (
            <div
              key={item.key}
              style={{
                textAlign: 'center',
                flex: 1,
                cursor: 'pointer',
                color: item.isActive(location.pathname) ? '#1890ff' : '#666',
                fontWeight: item.isActive(location.pathname) ? 'bold' : 'normal',
                transition: 'color 0.2s ease'
              }}
              onClick={() => handleMenuNavigate(item.path)}
            >
              <div style={{ fontSize: '20px', marginBottom: '4px' }}>
                {item.icon}
              </div>
              <div style={{ fontSize: '12px' }}>{item.label}</div>
            </div>
          ))}
        </div>
      </div>
    );
  }


  // 桌面端表格布局
  return (
    <div style={{ padding: '20px', minHeight: 'calc(100vh - 80px)' }}>
      <Table
        columns={columns}
        dataSource={orders}
        rowKey="id"
        loading={loading}
        scroll={{ x: 1000 }}
        pagination={{
          current: currentPage,
          pageSize: pageSize,
          total: total,
          showSizeChanger: true,
          showTotal: (total) => `共 ${total} 条`,
          onChange: (page, size) => {
            setCurrentPage(page);
            setPageSize(size);
          },
          onShowSizeChange: (current, size) => {
            setCurrentPage(1);
            setPageSize(size);
          }
        }}
      />
    </div>
  );
}

export default OrderList;

