import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Card,
  Table,
  Button,
  InputNumber,
  message,
  Modal,
  Space,
  Checkbox,
  Empty,
  Typography,
  Divider,
  Badge,
  Row,
  Col
} from 'antd';
import { DeleteOutlined, ShoppingOutlined } from '@ant-design/icons';
import { getCartList, updateCartItem, deleteCartItem } from '../api/front/cartApi';
import { commonMenuConfig } from '../components/Header';
import { getUserId, isLoggedIn } from '../utils/auth';

const { Title } = Typography;

function Cart() {
  const navigate = useNavigate();
  const location = useLocation();
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [updatingItems, setUpdatingItems] = useState(new Set()); // 正在更新的购物车项ID集合
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [cartCount, setCartCount] = useState(0);
  const [quantityInputs, setQuantityInputs] = useState({}); // 存储每个购物车项的临时输入值

  // 获取购物车列表
  const fetchCartList = async () => {
    if (!isLoggedIn()) {
      // 未登录时从localStorage获取
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartItems(localCart);
      // 默认选中所有商品
      if (localCart.length > 0) {
        const allIds = localCart.map(item => item.id);
        setSelectedRowKeys(allIds);
      }
      return;
    }

    setLoading(true);
    try {
      const userId = getUserId();
      if (!userId) {
        message.warning('用户信息获取失败，请重新登录');
        navigate('/login');
        return;
      }
      const res = await getCartList(userId);
      if (res.code === 200) {
        const items = res.data || [];
        setCartItems(items);
        // 清除所有临时输入状态，确保数据同步
        setQuantityInputs({});
        // 默认选中所有商品
        if (items.length > 0) {
          const allIds = items.map(item => item.id);
          setSelectedRowKeys(allIds);
        }
      }
    } catch (err) {
      message.error('获取购物车失败');
    } finally {
      setLoading(false);
    }
  };

  // 获取购物车数量（用于底部导航显示）
  const fetchCartCount = async () => {
    if (!isLoggedIn()) {
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      setCartCount(localCart.length);
      return;
    }
    try {
      const userId = getUserId();
      if (!userId) {
        setCartCount(0);
        return;
      }
      const res = await getCartList(userId);
      if (res.code === 200) {
        const count = res.data?.reduce((sum, item) => sum + (item.num || 0), 0) || 0;
        setCartCount(count);
      }
    } catch (err) {
    }
  };

  // 响应式处理
  const handleResize = () => {
    setIsMobile(window.innerWidth < 768);
  };

  // 导航处理
  const handleMenuNavigate = (path) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate(path);
  };

  useEffect(() => {
    fetchCartList();
    fetchCartCount();

    window.addEventListener('resize', handleResize);
    const handleCartUpdate = () => {
      fetchCartList();
      fetchCartCount();
    };
    window.addEventListener('cartUpdated', handleCartUpdate);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('cartUpdated', handleCartUpdate);
    };
  }, []);

  // 更新数量
  const handleQuantityChange = async (record, value) => {
    // 验证数量不能小于1
    if (value === null || value === undefined || value < 1) {
      message.warning('数量不能小于1');
      fetchCartList();
      return;
    }

    // 确保数量为整数
    const num = Math.floor(value);

    // 获取购物车项ID（从record中获取，确保数据中包含id字段）
    // 注意：id字段在购物车列表数据中是隐藏的，但必须存在，用于标识购物车项
    const cartItemId = record.id;
    if (!cartItemId) {
      message.error('购物车项ID获取失败，请刷新页面重试');
      return;
    }

    // 防止重复提交：如果该购物车项正在更新，则忽略本次请求
    if (updatingItems.has(cartItemId)) {
      return;
    }

    const isLoggedIn = !!localStorage.getItem('token');
    
    if (!isLoggedIn) {
      // 本地存储更新（未登录状态）
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      const updatedCart = localCart.map(item =>
        item.id === cartItemId ? { ...item, num } : item
      );
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      fetchCartList();
      return;
    }

    // 获取用户ID
    const userId = getUserId();
    if (!userId) {
      message.error('用户信息获取失败，请重新登录');
      navigate('/login');
      return;
    }

    // 标记该购物车项正在更新
    setUpdatingItems(prev => new Set(prev).add(cartItemId));

    // 调用后端API更新数量（PUT /cart/update/num）
    try {
      const res = await updateCartItem({
        id: cartItemId,
        userId: userId,
        num: num
      });

      if (res.code === 200) {
        message.success('数量更新成功');
        // 刷新购物车列表
        await fetchCartList();
        fetchCartCount(); // 更新购物车数量
        // 触发购物车更新事件（更新Header中的购物车数量）
        window.dispatchEvent(new Event('cartUpdated'));
      } else {
        message.error(res.msg || '数量更新失败');
        // 更新失败时，恢复列表
        fetchCartList();
      }
    } catch (err) {
      message.error('数量更新失败，请重试');
      // 更新失败时，恢复列表
      fetchCartList();
    } finally {
      // 8. 清除更新标记
      setUpdatingItems(prev => {
        const newSet = new Set(prev);
        newSet.delete(cartItemId);
        return newSet;
      });
    }
  };

  // 删除商品
  const handleDelete = async (record) => {
    const isLoggedIn = !!localStorage.getItem('token');
    
    if (!isLoggedIn) {
      const localCart = JSON.parse(localStorage.getItem('cart') || '[]');
      const updatedCart = localCart.filter(item => item.id !== record.id);
      localStorage.setItem('cart', JSON.stringify(updatedCart));
      fetchCartList();
      message.success('删除成功');
      return;
    }

    try {
      const userId = getUserId();
      if (!userId) {
        message.error('用户信息获取失败');
        return;
      }
      const res = await deleteCartItem({ id: record.id, userId });
      if (res.code === 200) {
        message.success('删除成功');
        // 从选中列表中移除已删除的商品
        setSelectedRowKeys(prev => prev.filter(key => {
          const itemId = record.id;
          return key !== itemId && String(key) !== String(itemId) && Number(key) !== Number(itemId);
        }));
        fetchCartList();
        fetchCartCount(); // 更新购物车数量
        window.dispatchEvent(new Event('cartUpdated'));
      }
    } catch (err) {
      message.error('删除失败');
    }
  };

  // 表格列配置（桌面端）
  const columns = [
    {
      title: '商品图片',
      key: 'goodsImg',
      width: 100,
      align: 'center',
      render: (_, record) => (
        <img
          src={record.goodsImg || record.goods?.goodsImg || ''}
          alt={record.goodsName || record.goods?.goodsName || '商品图片'}
          style={{ 
            width: '80px', 
            height: '80px', 
            objectFit: 'cover', 
            borderRadius: '4px',
            border: '1px solid #e8e8e8'
          }}
          onError={(e) => {
            e.target.src = 'https://via.placeholder.com/80x80?text=No+Image';
          }}
        />
      )
    },
    {
      title: '商品名称',
      key: 'goodsName',
      width: 200,
      ellipsis: {
        showTitle: false,
      },
      render: (_, record) => (
        <div>
          <div style={{ fontWeight: 'bold', marginBottom: '4px' }}>
            <span title={record.goodsName || record.goods?.goodsName || '-'}>
              {record.goodsName || record.goods?.goodsName || '-'}
            </span>
          </div>
          {record.barCode && (
            <div style={{ color: '#999', fontSize: '12px' }}>条形码: {record.barCode}</div>
          )}
        </div>
      )
    },
    {
      title: '单价',
      dataIndex: 'goodsPrice',
      key: 'goodsPrice',
      width: 120,
      render: (price, record) => (
        <span style={{ fontSize: '16px', color: '#ff4d4f' }}>
          ¥{Number(price || record.goods?.goodsPrice || 0).toFixed(2)}
        </span>
      )
    },
    {
      title: '数量',
      key: 'num',
      width: 180,
      render: (_, record) => {
        const cartItemId = record.id;
        const isUpdating = updatingItems.has(cartItemId);
        // 获取可用数量
        const stockNum = record.stockNum || 0;
        const currentNum = record.num || record.quantity || 1;
        // 使用临时输入值，如果不存在则使用当前数量
        const inputValue = quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : currentNum;
        
        return (
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <InputNumber
              min={1}
              value={inputValue}
              onChange={(value) => {
                // 更新临时状态
                if (value !== null && value !== undefined) {
                  setQuantityInputs(prev => ({
                    ...prev,
                    [cartItemId]: value
                  }));
                }
              }}
              onBlur={() => {
                // 失去焦点时触发更新
                const value = quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : currentNum;
                if (value !== null && value !== undefined) {
                  const numValue = Number(value);
                  if (numValue >= 1) {
                    handleQuantityChange(record, numValue);
                    // 清除临时状态
                    setQuantityInputs(prev => {
                      const newState = { ...prev };
                      delete newState[cartItemId];
                      return newState;
                    });
                  } else {
                    message.warning('数量不能小于1');
                    // 恢复为原来的数量
                    setQuantityInputs(prev => {
                      const newState = { ...prev };
                      delete newState[cartItemId];
                      return newState;
                    });
                    fetchCartList();
                  }
                }
              }}
              onPressEnter={() => {
                // 按回车时触发更新
                const value = quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : currentNum;
                if (value !== null && value !== undefined) {
                  const numValue = Number(value);
                  if (numValue >= 1) {
                    handleQuantityChange(record, numValue);
                    // 清除临时状态
                    setQuantityInputs(prev => {
                      const newState = { ...prev };
                      delete newState[cartItemId];
                      return newState;
                    });
                  } else {
                    message.warning('数量不能小于1');
                    // 恢复为原来的数量
                    setQuantityInputs(prev => {
                      const newState = { ...prev };
                      delete newState[cartItemId];
                      return newState;
                    });
                    fetchCartList();
                  }
                }
              }}
              precision={0}
              disabled={isUpdating} // 更新时禁用输入
              parser={(value) => {
                // 确保输入的是整数
                return value ? Math.floor(parseFloat(value.replace(/\$\s?|(,*)/g, ''))) : '';
              }}
              formatter={(value) => {
                // 格式化显示为整数
                return value ? Math.floor(value).toString() : '';
              }}
            />
            <span style={{ fontSize: '12px', color: '#666' }}>
              可用数量: {stockNum}
            </span>
          </div>
        );
      }
    },
    {
      title: '小计',
      key: 'subtotal',
      width: 120,
      render: (_, record) => {
        const price = record.goodsPrice || record.goods?.goodsPrice || 0;
        const num = record.num || record.quantity || 1;
        return (
          <span style={{ fontSize: '16px', color: '#ff4d4f', fontWeight: 'bold' }}>
            ¥{(price * num).toFixed(2)}
          </span>
        );
      }
    },
    {
      title: '操作',
      key: 'action',
      width: 100,
      render: (_, record) => (
        <Button
          type="link"
          danger
          icon={<DeleteOutlined />}
          onClick={() => handleDelete(record)}
        >
          删除
        </Button>
      )
    }
  ];

  // 计算总数量（所有选中商品的数量总和）
  const totalQuantity = useMemo(() => {
    if (!selectedRowKeys || selectedRowKeys.length === 0) {
      return 0;
    }
    
    const total = selectedRowKeys.reduce((sum, key) => {
      // 确保类型匹配（字符串和数字都支持）
      const item = cartItems.find(i => {
        const itemId = i.id;
        const keyId = key;
        // 支持字符串和数字类型的匹配
        return itemId === keyId || String(itemId) === String(keyId) || Number(itemId) === Number(keyId);
      });
      
      if (item) {
        const num = Number(item.num || item.quantity || 1);
        return sum + num;
      }
      return sum;
    }, 0);
    
    return total;
  }, [selectedRowKeys, cartItems]);

  // 计算平均单价（所有选中商品的平均价格）
  const averagePrice = useMemo(() => {
    if (!selectedRowKeys || selectedRowKeys.length === 0 || totalQuantity === 0) {
      return 0;
    }
    
    // 先计算总金额
    const totalAmount = selectedRowKeys.reduce((sum, key) => {
      const item = cartItems.find(i => {
        const itemId = i.id;
        const keyId = key;
        return itemId === keyId || String(itemId) === String(keyId) || Number(itemId) === Number(keyId);
      });
      
      if (item) {
        const price = Number(item.goodsPrice || item.goods?.goodsPrice || 0);
        const num = Number(item.num || item.quantity || 1);
        return sum + (price * num);
      }
      return sum;
    }, 0);
    
    // 平均单价 = 总金额 / 总数量
    return totalAmount / totalQuantity;
  }, [selectedRowKeys, cartItems, totalQuantity]);

  // 计算总价（总数量 × 平均单价）
  const totalPrice = useMemo(() => {
    return totalQuantity * averagePrice;
  }, [totalQuantity, averagePrice]);

  // 结算
  const handleCheckout = () => {
    const selectedCount = selectedRowKeys ? selectedRowKeys.length : 0;
    if (selectedCount === 0) {
      message.warning('请选择要结算的商品');
      return;
    }

    const isLoggedIn = !!localStorage.getItem('token');
    if (!isLoggedIn) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }

    // 检查选中商品的数量是否超过可用库存
    const invalidItems = [];
    selectedRowKeys.forEach(key => {
      const item = cartItems.find(i => {
        const itemId = i.id;
        const keyId = key;
        return itemId === keyId || String(itemId) === String(keyId) || Number(itemId) === Number(keyId);
      });
      
      if (item) {
        const num = Number(item.num || item.quantity || 1);
        // 获取可用数量
        const stockNum = Number(item.stockNum || 0);
        
        // 数量必须小于等于可用数量
        if (stockNum > 0 && num > stockNum) {
          invalidItems.push({
            goodsName: item.goodsName || item.goods?.goodsName || '未知商品',
            num: num,
            stockNum: stockNum
          });
        }
      }
    });

    // 如果有数量超过库存的商品，阻止提交并提示
    if (invalidItems.length > 0) {
      const errorMessages = invalidItems.map((item, index) => 
        `${index + 1}. ${item.goodsName}：购买数量(${item.num})大于可用数量(${item.stockNum})`
      ).join('\n');
      
      Modal.warning({
        title: '数量超过可用数量',
        content: (
          <div>
            <p style={{ marginBottom: '12px', fontWeight: 'bold', color: '#ff4d4f' }}>
              以下商品数量超过可用数量，请修改数量后再结算：
            </p>
            <div style={{ 
              marginTop: '12px', 
              padding: '12px', 
              background: '#fff7e6', 
              borderRadius: '4px',
              whiteSpace: 'pre-line',
              lineHeight: '1.8',
              border: '1px solid #ffd591'
            }}>
              {errorMessages}
            </div>
          </div>
        ),
        okText: '我知道了',
        width: 500
      });
      return;
    }

    // 跳转到订单页面，传递选中的商品ID
    navigate(`/order?cartIds=${selectedRowKeys.join(',')}`);
  };

  const rowSelection = {
    selectedRowKeys,
    onChange: (keys) => {
      setSelectedRowKeys(keys);
    }
  };

  return (
    <div style={{ 
      padding: isMobile ? '10px' : '20px 50px', 
      background: '#f5f5f5', 
      minHeight: 'calc(100vh - 80px)',
      paddingBottom: isMobile ? '80px' : '20px',
      boxSizing: 'border-box'
    }}>
      <Card>
        <Title level={3}>购物车</Title>
        <Divider />

        {cartItems.length === 0 ? (
          <Empty description="购物车是空的" />
        ) : (
          <>
            {/* 桌面端：使用表格 */}
            {!isMobile && (
              <Table
                rowSelection={rowSelection}
                columns={columns}
                dataSource={cartItems}
                rowKey="id"
                loading={loading}
                pagination={false}
                scroll={{ x: 'max-content' }}
              />
            )}

            {/* 移动端：使用卡片式布局 */}
            {isMobile && (
              <div>
                {cartItems.map((record) => {
                  const isSelected = selectedRowKeys.includes(record.id);
                  const cartItemId = record.id;
                  const isUpdating = updatingItems.has(cartItemId);
                  const price = record.goodsPrice || record.goods?.goodsPrice || 0;
                  const num = record.num || record.quantity || 1;
                  
                  return (
                    <Card
                      key={record.id}
                      style={{ marginBottom: '12px' }}
                      bodyStyle={{ padding: '12px' }}
                    >
                      <div style={{ display: 'flex', gap: '12px' }}>
                        <Checkbox
                          checked={isSelected}
                          onChange={(e) => {
                            const newKeys = e.target.checked
                              ? [...selectedRowKeys, record.id]
                              : selectedRowKeys.filter(key => {
                                  // 支持字符串和数字类型的匹配
                                  return key !== record.id && String(key) !== String(record.id) && Number(key) !== Number(record.id);
                                });
                            setSelectedRowKeys(newKeys);
                          }}
                        />
                        <img
                          src={record.goodsImg || record.goods?.goodsImg}
                          alt={record.goodsName || record.goods?.goodsName}
                          style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '4px', flexShrink: 0 }}
                        />
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontWeight: 'bold', marginBottom: '8px', fontSize: '14px' }}>
                            {record.goodsName || record.goods?.goodsName}
                          </div>
                          <div style={{ marginBottom: '8px' }}>
                            <span style={{ fontSize: '16px', color: '#ff4d4f', fontWeight: 'bold' }}>
                              ¥{Number(price).toFixed(2)}
                            </span>
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                            <span style={{ fontSize: '12px', color: '#666' }}>数量：</span>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                              <InputNumber
                                min={1}
                                value={quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : num}
                                onChange={(value) => {
                                  // 更新临时状态
                                  if (value !== null && value !== undefined) {
                                    setQuantityInputs(prev => ({
                                      ...prev,
                                      [cartItemId]: value
                                    }));
                                  }
                                }}
                                onBlur={() => {
                                  // 失去焦点时触发更新
                                  const value = quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : num;
                                  if (value !== null && value !== undefined) {
                                    const numValue = Number(value);
                                    if (numValue >= 1) {
                                      handleQuantityChange(record, numValue);
                                      // 清除临时状态
                                      setQuantityInputs(prev => {
                                        const newState = { ...prev };
                                        delete newState[cartItemId];
                                        return newState;
                                      });
                                    } else {
                                      message.warning('数量不能小于1');
                                      // 恢复为原来的数量
                                      setQuantityInputs(prev => {
                                        const newState = { ...prev };
                                        delete newState[cartItemId];
                                        return newState;
                                      });
                                      fetchCartList();
                                    }
                                  }
                                }}
                                onPressEnter={() => {
                                  // 按回车时触发更新
                                  const value = quantityInputs[cartItemId] !== undefined ? quantityInputs[cartItemId] : num;
                                  if (value !== null && value !== undefined) {
                                    const numValue = Number(value);
                                    if (numValue >= 1) {
                                      handleQuantityChange(record, numValue);
                                      // 清除临时状态
                                      setQuantityInputs(prev => {
                                        const newState = { ...prev };
                                        delete newState[cartItemId];
                                        return newState;
                                      });
                                    } else {
                                      message.warning('数量不能小于1');
                                      // 恢复为原来的数量
                                      setQuantityInputs(prev => {
                                        const newState = { ...prev };
                                        delete newState[cartItemId];
                                        return newState;
                                      });
                                      fetchCartList();
                                    }
                                  }
                                }}
                                precision={0}
                                disabled={isUpdating}
                                size="small"
                                style={{ width: '80px' }}
                                parser={(value) => {
                                  return value ? Math.floor(parseFloat(value.replace(/\$\s?|(,*)/g, ''))) : '';
                                }}
                                formatter={(value) => {
                                  return value ? Math.floor(value).toString() : '';
                                }}
                              />
                              <span style={{ fontSize: '12px', color: '#666' }}>
                                可用数量: {record.stockNum || 0}
                              </span>
                            </div>
                          </div>
                          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <span style={{ fontSize: '14px', color: '#666' }}>
                              小计: <span style={{ color: '#ff4d4f', fontWeight: 'bold' }}>¥{(price * num).toFixed(2)}</span>
                            </span>
                            <Button
                              type="link"
                              danger
                              size="small"
                              icon={<DeleteOutlined />}
                              onClick={() => handleDelete(record)}
                            >
                              删除
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}

            {/* 底部结算区域 */}
            <div style={{ 
              marginTop: '24px', 
              textAlign: isMobile ? 'center' : 'right',
              padding: isMobile ? '12px' : '0',
              background: isMobile ? '#fff' : 'transparent',
              borderRadius: isMobile ? '8px' : '0',
              border: isMobile ? '1px solid #f0f0f0' : 'none'
            }}>
              <Space 
                size="large" 
                align="end" 
                direction={isMobile ? 'vertical' : 'horizontal'}
                style={{ width: isMobile ? '100%' : 'auto' }}
              >
                <div style={{ textAlign: isMobile ? 'center' : 'left' }}>
                  <div style={{ fontSize: isMobile ? '14px' : '16px', marginBottom: isMobile ? '8px' : '4px', color: '#666' }}>
                    数量合计: <span style={{ fontWeight: 'bold', color: '#1890ff' }}>{totalQuantity}</span> 件
                  </div>
                  <div style={{ fontSize: isMobile ? '18px' : '20px', fontWeight: 'bold', marginTop: '8px' }}>
                    总金额: <span style={{ color: '#ff4d4f', fontSize: isMobile ? '20px' : '24px' }}>¥{totalPrice.toFixed(2)}</span>
                  </div>
                </div>
                <Button
                  type="primary"
                  size={isMobile ? 'middle' : 'large'}
                  icon={<ShoppingOutlined />}
                  onClick={handleCheckout}
                  disabled={!selectedRowKeys || selectedRowKeys.length === 0}
                  block={isMobile}
                >
                  去结算
                </Button>
              </Space>
            </div>
          </>
        )}
      </Card>

      {/* 移动端底部导航 */}
      <div style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: '#fff',
        borderTop: '1px solid #f0f0f0',
        zIndex: 999,
        display: isMobile ? 'flex' : 'none',
        justifyContent: 'space-around',
        alignItems: 'center',
        padding: '10px 0',
        boxShadow: '0 -2px 10px rgba(0,0,0,0.1)',
        boxSizing: 'border-box'
      }}>
        {commonMenuConfig.map(item => (
          <div
            key={item.key}
            style={{
              textAlign: 'center',
              flex: 1,
              cursor: 'pointer',
              color: item.isActive(location.pathname) ? '#1890ff' : '#666',
              fontWeight: item.isActive(location.pathname) ? 'bold' : 'normal',
              transition: 'color 0.2s ease'
            }}
            onClick={() => handleMenuNavigate(item.path)}
          >
            <div style={{ fontSize: '20px', marginBottom: '4px' }}>
              {item.key === 'cart' ? <Badge count={cartCount} showZero>{item.icon}</Badge> : item.icon}
            </div>
            <div style={{ fontSize: '12px' }}>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Cart;

