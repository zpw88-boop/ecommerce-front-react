import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Card, Tabs, Button, Form, Input, message, Avatar } from 'antd';
import { UserOutlined, ShoppingOutlined } from '@ant-design/icons';
import { getUserInfo, updateUserInfo } from '../api/front/userApi';
import { getUserId, clearUserInfo } from '../utils/auth';
import OrderList from './OrderList';

const { TabPane } = Tabs;
const { Password } = Input;

// 校验正则
const validateRules = {
  password: /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,18}$/,
  phone: /^1[3-9]\d{9}$/,
  nickname: /^[\u4e00-\u9fa5a-zA-Z0-9]{2,10}$/
};

function UserProfile() {
  const navigate = useNavigate();
  const location = useLocation();
  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form] = Form.useForm();
  
  // 根据路由切换Tab
  const [activeTab, setActiveTab] = useState(location.pathname === '/orders' ? 'orders' : 'profile');

  // 根据路由切换Tab
  useEffect(() => {
    if (location.pathname === '/orders') {
      setActiveTab('orders');
    } else if (location.pathname === '/profile') {
      setActiveTab('profile');
    }
  }, [location.pathname]);

  // 检查登录状态并获取用户信息
  useEffect(() => {
    const userId = getUserId();
    if (!userId) {
      message.warning('请先登录');
      navigate('/login');
      return;
    }
    fetchUserInfo();
  }, [navigate]);

  // 获取用户信息
  const fetchUserInfo = async () => {
    const userId = getUserId();
    if (!userId) {
      return;
    }

    setLoading(true);
    try {
      const res = await getUserInfo(userId);
      
      if (res.code === 200) {
        const data = res.data || {};
        setUserInfo(data);
        // 设置表单初始值
        form.setFieldsValue({
          id: data.id,
          username: data.username,
          nickname: data.nickname || '',
          phone: data.phone || '',
          email: data.email || '',
          password: '' // 密码不预填充
        });
      } else {
        message.error(res.msg || '获取用户信息失败');
      }
    } catch (err) {
      const errorMsg = err.response?.data?.msg || err.message || '获取用户信息失败';
      message.error(errorMsg);
    } finally {
      setLoading(false);
    }
  };

  // 保存用户信息
  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      setSaving(true);

      const userId = getUserId();
      
      if (!userId) {
        message.error('用户ID获取失败，请重新登录');
        navigate('/login');
        return;
      }

      // 构造提交数据
      const updateData = {
        id: values.id || userId,
        nickname: values.nickname,
        phone: values.phone,
        email: values.email
      };

      // 如果填写了密码，则包含在更新数据中
      if (values.password && values.password.trim() !== '') {
        updateData.password = values.password;
      }
      
      const res = await updateUserInfo(updateData);
      
      if (res.code === 200) {
        message.success(res.msg || '保存成功');
        message.info('个人信息已修改，请重新登录');
        
        // 清除用户信息
        clearUserInfo();
        
        // 触发用户信息更新事件，通知Header清除用户信息
        window.dispatchEvent(new Event('userInfoUpdated'));
        
        // 延迟跳转
        setTimeout(() => {
          navigate('/login');
        }, 1500);
      } else {
        message.error(res.msg || '保存失败');
      }
    } catch (err) {
      if (err.errorFields) {
        message.error('请检查输入信息');
      } else {
        const errorMsg = err.response?.data?.msg || err.message || '保存失败';
        message.error(errorMsg);
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ padding: '20px 50px', background: '#f5f5f5', minHeight: 'calc(100vh - 80px)' }}>
      <Card>
        <Tabs activeKey={activeTab} onChange={setActiveTab}>
          {/* 个人信息 */}
          <TabPane
            tab={
              <span>
                <UserOutlined />
                个人信息
              </span>
            }
            key="profile"
          >
            {userInfo && (
              <div>
                {/* 头部信息：头像+昵称+用户名 */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  marginBottom: '24px',
                  paddingBottom: '20px',
                  borderBottom: '1px solid #f0f0f0'
                }}>
                  <Avatar
                    icon={<UserOutlined />}
                    size={64}
                    src={userInfo.avatar}
                    style={{ backgroundColor: '#1890ff', marginRight: '16px' }}
                  />
                  <div>
                    <h3 style={{ margin: 0, color: '#1890ff', fontSize: '18px' }}>
                      {userInfo.nickname || userInfo.username}
                    </h3>
                    <p style={{ margin: '4px 0 0 0', color: '#666', fontSize: '14px' }}>
                      用户名：{userInfo.username}
                    </p>
                  </div>
                </div>

                {/* 用户信息表单 */}
                <Form
                  form={form}
                  layout="vertical"
                  labelCol={{ span: 6 }}
                  wrapperCol={{ span: 18 }}
                >
                  <Form.Item name="id" label="用户ID" hidden>
                    <Input disabled />
                  </Form.Item>

                  <Form.Item name="username" label="用户名">
                    <Input disabled size="small" />
                  </Form.Item>

                  <Form.Item
                    name="nickname"
                    label="昵称"
                    rules={[
                      { required: true, message: '请输入昵称！' },
                      { pattern: validateRules.nickname, message: '昵称支持中文、字母、数字，需2-10位！' },
                      { min: 2, message: '昵称至少2个字符！' },
                      { max: 10, message: '昵称最多10个字符！' }
                    ]}
                  >
                    <Input placeholder="请输入2-10位中文、字母或数字" size="small" />
                  </Form.Item>

                  <Form.Item
                    name="phone"
                    label="手机号"
                    rules={[
                      { required: true, message: '请输入手机号！' },
                      { pattern: validateRules.phone, message: '请输入正确的11位手机号！' }
                    ]}
                  >
                    <Input placeholder="请输入11位手机号" size="small" />
                  </Form.Item>

                  <Form.Item
                    name="email"
                    label="邮箱"
                    rules={[
                      { required: true, message: '请输入邮箱！' },
                      { type: 'email', message: '请输入正确的邮箱格式！' }
                    ]}
                  >
                    <Input placeholder="请输入您的邮箱地址" size="small" />
                  </Form.Item>

                  <Form.Item
                    name="password"
                    label="密码（不填则不修改）"
                    rules={[
                      { pattern: validateRules.password, message: '密码需为6-18位字母+数字组合！' },
                      { min: 6, message: '密码至少6个字符！' },
                      { max: 18, message: '密码最多18个字符！' }
                    ]}
                  >
                    <Password placeholder="可选：输入6-18位字母+数字组合密码（不填则不修改）" size="small" />
                  </Form.Item>

                  <Form.Item>
                    <Button
                      type="primary"
                      onClick={handleSave}
                      loading={saving}
                      size="small"
                      style={{ width: '120px' }}
                    >
                      保存
                    </Button>
                  </Form.Item>
                </Form>
              </div>
            )}
          </TabPane>

          {/* 我的订单 */}
          <TabPane
            tab={
              <span>
                <ShoppingOutlined />
                我的订单
              </span>
            }
            key="orders"
          >
            <OrderList />
          </TabPane>
        </Tabs>
      </Card>
    </div>
  );
}

export default UserProfile;

