import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import FrontHome from './pages/FrontHome';
import ProductList from './pages/ProductList';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import UserProfile from './pages/UserProfile';
import OrderList from './pages/OrderList';
import Order from './pages/Order';
import OrderDetail from './pages/OrderDetail';
import Login from './pages/Login';
import Register from './pages/Register';

function App() {
  return (
        <>
      <Header />
      <div style={{ minHeight: 'calc(100vh - 80px)' }}>
        <Routes>
          {/* 前台路由 */}
          <Route path="/" element={<FrontHome />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/products/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/profile" element={<UserProfile />} />
          <Route path="/orders" element={<OrderList />} />
          <Route path="/orders/:id" element={<OrderDetail />} />
          <Route path="/order" element={<Order />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          
          {/* 兜底路由 */}
                                <Route path="*" element={<Navigate to="/" replace />} />
                            </Routes>
      </div>
        </>
    );
}

export default App;