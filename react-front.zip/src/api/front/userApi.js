import request from '../../utils/request';

/**
 * 用户登录
 */
export const login = (data) => {
  return request.post('/api/auth/login', data);
};

/**
 * 用户注册
 */
export const register = (data) => {
  return request.post('/api/userfront/register', data);
};

/**
 * 获取当前登录用户信息
 */
export const getCurrentUserInfo = () => {
  return request.get('/api/userfront/info');
};

/**
 * 根据用户ID获取用户信息
 */
export const getUserInfo = (userId) => {
  return request.get(`/api/userfront/${userId}`);
};

/**
 * 更新个人信息
 */
export const updateUserInfo = (data) => {
  return request.put('/api/userfront/update/self', data);
};


