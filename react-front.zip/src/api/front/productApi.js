import request from '../../utils/request';

/**
 * 分页查询商品
 */
export const getGoodsPage = (params) => {
  return request.get('/api/front/goods/page', { params });
};

/**
 * 查询商品详情
 */
export const getProductDetail = (id) => {
  // 先尝试使用前台路径（如果后端有提供）
  return request.get(`/api/front/goods/${id}`);
};

